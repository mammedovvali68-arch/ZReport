# ZReport 1.0.0 - Kurulum ve Kullanım

## Derleme
Gereksinimler: JDK 17+ ve Maven.

    mvn clean package

Çıktı: `target/ZReport-1.0.0.jar` (SQLite JDBC içine gömülüdür).

## Kurulum
1. JAR dosyasını sunucunun `plugins/` klasörüne at.
2. Sunucuyu başlat (Paper 1.20.x ve üzeri). `plugins/ZReport/config.yml` ve `reports.db` otomatik oluşur.
3. Ayarları değiştirdikten sonra sunucuyu yeniden başlat.

## Komutlar
| Komut | Yetki | Açıklama |
|---|---|---|
| /rapor <oyuncu> [sebep] | zreport.report | Oyuncuyu raporlar |
| /raporlist [sayfa] | zreport.list | GUI (oyuncu) veya sohbet listesi (konsol) |
| /rapordetay <ID> | zreport.list | Rapor ayrıntıları |
| /raporsil <ID> | zreport.admin | Önce onay ister, sonra `/raporsil <ID> onayla` |
| /raportemizle | zreport.admin | Önce onay ister, sonra `/raportemizle onayla` |

Yetkiler: `zreport.report` (varsayılan: herkes), `zreport.list` (op), `zreport.admin` (op; report ve list'i de kapsar, cooldown'dan muaftır).

## GUI
Rapor listesinde bir rapora tıklayınca ayrıntı menüsü açılır. Admin, ayrıntı menüsündeki TNT butonuna iki kez tıklayarak raporu siler. Tüm envanter tıklama/sürükleme işlemleri iptal edilir.
Sohbet listesi istersen `settings.use-gui: false` yap.

## Notlar
- Veritabanı işlemleri ayrı bir thread'de çalışır, sonuçlar ana thread'e döner.
- API 1.20.4'e karşı derlenir; 1.20.x ve 1.21.x sunucularda çalışması hedeflenmiştir.
