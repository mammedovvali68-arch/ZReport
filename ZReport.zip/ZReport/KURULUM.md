# ZReport V2 - Kurulum ve Kullanım

## V1'den yükseltme (verilerin korunur)
1. Sunucuyu kapat.
2. `plugins/` içindeki eski ZReport JAR'ını yenisiyle değiştir (aynı isim: `ZReport-1.0.0.jar`; eklenti sürümü 2.0.0 görünür).
3. Sunucuyu aç. İlk açılışta:
   - `plugins/ZReport/reports.db` V2 şemasına yükseltilir, eski raporlar silinmez ve ACTIVE olarak işaretlenir.
   - Eski veritabanı `reports-v1-backup.db` olarak yedeklenir.
   - Mevcut `config.yml` değerlerin korunarak eksik V2 ayarlarıyla tamamlanır.
4. Konsolda "Veritabanı V2 şemasına yükseltildi" yazısını gör.

## Derleme
GitHub'daki `ZReport.zip` dosyasını yenisiyle değiştir (Add file -> Upload files, aynı ad). Actions otomatik derler, `ZReport-jar` artifact'ını indir.

## Komutlar
| Komut | Yetki | Açıklama |
|---|---|---|
| /rapor | zreport.report | Oyuncu seçim menüsü -> rapor menüsü |
| /rapor <oyuncu> [sebep] | zreport.report | V1 hızlı komutu (config'den kapatılabilir) |
| /raporlist | zreport.list | Yönetim paneli (ACTIVE / REVIEWED / PUNISHED) |
| /raporlist <active/reviewed/punished> [sayfa] | zreport.list | Doğrudan kategori |
| /rapordetay <ID> | zreport.list | Rapor detay menüsü |
| /raporsil <ID> | zreport.admin | Silme (onaylı) |
| /raportemizle | zreport.admin | Hepsini sil (onaylı) |

## Yetkiler
- `zreport.report` (herkes): rapor gönderme
- `zreport.list` (op): paneli, detayları ve geçmişi görme, yeni rapor bildirimi
- `zreport.review` (op): MARK AS REVIEWED
- `zreport.punish` (op): PUNISH PLAYER
- `zreport.admin` (op): hepsini kapsar + silme/temizleme, cooldown muafiyeti

## Kullanım
**Oyuncu:** /rapor -> bir kafaya tıkla -> sebep (sohbete yaz, `gec` ile atla, `iptal`) -> kanıt YES/NO -> RAPORLA.
**Yetkili:** /raporlist -> kategori -> rapora tıkla -> detay.
- MARK AS REVIEWED: sol tık not yazarak, sağ tık notsuz.
- PUNISH PLAYER: ceza türü (TEMPBAN için süre) -> sebep (sohbet) -> uygulanır.
- Ceza gerçekten uygulanamazsa (ör. çevrimdışı oyuncuya KICK) rapor PUNISHED olmaz.
- Rapor silme: detay menüsünde TNT'ye iki kez tıkla.

## Ceza sağlayıcısı
`punishment.provider: PAPER` (varsayılan) Paper ban listesini kullanır.
LiteBans vb. için `COMMAND` seçip `punishment.commands` komutlarını ayarla.

## Notlar
- Kanıt yalnızca oyuncunun beyanıdır, dosya yükleme yoktur ve menüde öyle gösterilir.
- Tüm menü başlıkları, item adları, lore'lar, renkler ve mesajlar config.yml'den değişir.
- Paper 1.20.x/1.21.x ve Java 17+ gerekir.
