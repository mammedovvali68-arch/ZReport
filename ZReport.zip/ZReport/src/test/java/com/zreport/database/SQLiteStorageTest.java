package com.zreport.database;

import com.zreport.models.Report;
import com.zreport.models.ReportStatus;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.logging.Logger;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Gerçek SQLite dosyası üzerinde entegrasyon testleri (Bukkit gerektirmez). */
class SQLiteStorageTest {

    private static final Logger LOG = Logger.getLogger("ZReportTest");
    private static final String STEVE = "11111111-1111-1111-1111-111111111111";
    private static final String NOTCH = "22222222-2222-2222-2222-222222222222";
    private static final String ALEX = "33333333-3333-3333-3333-333333333333";

    @TempDir
    Path dir;

    private File dbFile;
    private Connection connection;
    private SQLiteStorage storage;

    @BeforeEach
    void setUp() throws Exception {
        dbFile = dir.resolve("reports.db").toFile();
        connection = DriverManager.getConnection("jdbc:sqlite:" + dbFile.getAbsolutePath());
        DatabaseMigration.run(connection, dbFile, LOG);
        storage = new SQLiteStorage(connection);
    }

    @AfterEach
    void tearDown() {
        storage.close();
    }

    private Report draft(String reportedUuid, String reportedName, String reporterUuid, String reason) {
        return Report.create(reportedName, reportedUuid, "Reporter", reporterUuid, reason, false);
    }

    @Test
    void insertAssignsIncreasingIdsAndRoundTrips() throws Exception {
        Report first = storage.insert(Report.create("Steve", STEVE, "Alex", ALEX, "Hile kullanıyor", true));
        Report second = storage.insert(draft(NOTCH, "Notch", ALEX, "Küfür"));
        assertEquals(1, first.id());
        assertEquals(2, second.id());

        Report loaded = storage.getById(1).orElseThrow();
        assertEquals("Steve", loaded.reportedName());
        assertEquals(STEVE, loaded.reportedUuid());
        assertEquals("Hile kullanıyor", loaded.reason());
        assertTrue(loaded.evidence());
        assertEquals(ReportStatus.ACTIVE, loaded.status());
    }

    @Test
    void invalidIdsAreHandledSafely() throws Exception {
        assertEquals(Optional.empty(), storage.getById(0));
        assertEquals(Optional.empty(), storage.getById(-5));
        assertEquals(Optional.empty(), storage.getById(999));
        assertFalse(storage.delete(0));
        assertFalse(storage.delete(999));
        assertFalse(storage.markReviewed(-1, "u", "n", null, 1L));
        assertFalse(storage.markPunished(0, "KICK", "r", 0, "u", "n", 1L));
    }

    @Test
    void statusTransitionsAreAtomicAndNotRepeatable() throws Exception {
        Report report = storage.insert(draft(STEVE, "Steve", ALEX, "Hile"));
        assertTrue(storage.markReviewed(report.id(), "staff-uuid", "Mod", "temiz", 1000L));
        // ikinci yetkili aynı anda işlerse reddedilmeli
        assertFalse(storage.markReviewed(report.id(), "other", "Mod2", null, 2000L));

        Report reviewed = storage.getById(report.id()).orElseThrow();
        assertEquals(ReportStatus.REVIEWED, reviewed.status());
        assertEquals("Mod", reviewed.reviewedByName());
        assertEquals("temiz", reviewed.reviewNote());

        assertTrue(storage.markPunished(report.id(), "TEMPBAN", "Hile", 86400, "staff-uuid", "Mod", 3000L));
        assertFalse(storage.markPunished(report.id(), "KICK", "tekrar", 0, "x", "y", 4000L));

        Report punished = storage.getById(report.id()).orElseThrow();
        assertEquals(ReportStatus.PUNISHED, punished.status());
        assertEquals("TEMPBAN", punished.punishmentType());
        assertEquals(86400, punished.punishmentDuration());
        // incelenmiş raporun geçmişi korunur
        assertEquals("Mod", punished.reviewedByName());
        // cezalı rapor tekrar REVIEWED yapılamaz
        assertFalse(storage.markReviewed(report.id(), "u", "n", null, 5000L));
    }

    @Test
    void pagingAndOrdering() throws Exception {
        for (int i = 1; i <= 10; i++) {
            storage.insert(draft(STEVE, "Steve", ALEX, "sebep " + i));
        }
        List<Report> ascending = storage.getPage(null, 0, 4, false);
        assertEquals(List.of(1, 2, 3, 4), ids(ascending));
        List<Report> descending = storage.getPage(null, 0, 4, true);
        assertEquals(List.of(10, 9, 8, 7), ids(descending));
        assertEquals(List.of(9, 10), ids(storage.getPage(null, 8, 4, false)));

        storage.markReviewed(2, "u", "n", null, 1L);
        assertEquals(List.of(2), ids(storage.getPage(ReportStatus.REVIEWED, 0, 10, false)));
        assertEquals(9, storage.getPage(ReportStatus.ACTIVE, 0, 100, false).size());
    }

    @Test
    void statusAndTargetCounts() throws Exception {
        storage.insert(draft(STEVE, "Steve", ALEX, "a"));
        storage.insert(draft(STEVE, "Steve", NOTCH, "b"));
        storage.insert(draft(NOTCH, "Notch", ALEX, "c"));
        storage.markReviewed(1, "u", "n", null, 1L);
        storage.markPunished(2, "KICK", "r", 0, "u", "n", 1L);

        assertArrayEquals(new int[]{1, 1, 1}, storage.statusCounts());
        // [toplam, aktif, incelenmiş, cezalı]
        assertArrayEquals(new int[]{2, 0, 1, 1}, storage.targetCounts(STEVE, "Steve"));
        assertArrayEquals(new int[]{1, 1, 0, 0}, storage.targetCounts(NOTCH, "Notch"));
        assertArrayEquals(new int[]{0, 0, 0, 0}, storage.targetCounts("99999999-9999-9999-9999-999999999999", "Nobody"));
    }

    @Test
    void targetTotalsUsesBatchQueries() throws Exception {
        storage.insert(draft(STEVE, "Steve", ALEX, "a"));
        storage.insert(draft(STEVE, "Steve", NOTCH, "b"));
        storage.insert(draft(null, "OfflineGuy", ALEX, "c"));
        storage.insert(draft(null, "offlineguy", NOTCH, "d")); // isim büyük/küçük harf duyarsız
        storage.insert(draft(NOTCH, "Notch", ALEX, "e"));

        List<Report> page = storage.getPage(null, 0, 10, false);
        Map<Integer, Integer> totals = storage.targetTotals(page);
        assertEquals(2, totals.get(1));
        assertEquals(2, totals.get(2));
        assertEquals(2, totals.get(3));
        assertEquals(2, totals.get(4));
        assertEquals(1, totals.get(5));
    }

    @Test
    void historyIsNewestFirstAndPaged() throws Exception {
        for (int i = 1; i <= 5; i++) {
            storage.insert(draft(STEVE, "Steve", ALEX, "sebep " + i));
        }
        storage.insert(draft(NOTCH, "Notch", ALEX, "baska"));
        assertEquals(List.of(5, 4), ids(storage.targetPage(STEVE, "Steve", 0, 2)));
        assertEquals(List.of(3, 2), ids(storage.targetPage(STEVE, "Steve", 2, 2)));
        assertEquals(List.of(1), ids(storage.targetPage(STEVE, "Steve", 4, 2)));
    }

    @Test
    void duplicateActiveDetection() throws Exception {
        storage.insert(draft(STEVE, "Steve", ALEX, "a"));
        assertTrue(storage.existsActive(ALEX, STEVE, "Steve"));
        assertFalse(storage.existsActive(NOTCH, STEVE, "Steve"));
        assertFalse(storage.existsActive(ALEX, NOTCH, "Notch"));
        // incelendikten sonra aynı hedefe tekrar rapor verilebilir
        storage.markReviewed(1, "u", "n", null, 1L);
        assertFalse(storage.existsActive(ALEX, STEVE, "Steve"));
        // UUID'siz hedef isimle eşleşir
        storage.insert(draft(null, "OfflineGuy", ALEX, "x"));
        assertTrue(storage.existsActive(ALEX, null, "offlineguy"));
    }

    @Test
    void deleteAndClearResetIds() throws Exception {
        storage.insert(draft(STEVE, "Steve", ALEX, "a"));
        storage.insert(draft(STEVE, "Steve", ALEX, "b"));
        assertTrue(storage.delete(1));
        assertFalse(storage.delete(1));
        assertEquals(Optional.empty(), storage.getById(1));
        // silinen ID tekrar kullanılmaz
        assertEquals(3, storage.insert(draft(STEVE, "Steve", ALEX, "c")).id());

        assertEquals(2, storage.clear());
        assertArrayEquals(new int[]{0, 0, 0}, storage.statusCounts());
        // temizlemeden sonra ID sayacı sıfırlanır
        assertEquals(1, storage.insert(draft(STEVE, "Steve", ALEX, "yeni")).id());
    }

    @Test
    void sqlInjectionAttemptsAreStoredAsPlainText() throws Exception {
        String evil = "x'); DROP TABLE reports;--";
        storage.insert(Report.create("Steve", STEVE, "Alex", ALEX, evil, false));
        assertEquals(evil, storage.getById(1).orElseThrow().reason());
        assertArrayEquals(new int[]{0, 0, 0, 0}, storage.targetCounts(null, evil));
        assertEquals(1, storage.statusCounts()[0]);
    }

    @Test
    void corruptRowsAreSkippedInsteadOfBreakingTheList() throws Exception {
        storage.insert(draft(STEVE, "Steve", ALEX, "iyi"));
        // NOT NULL olmayan alanlara bozuk değer yaz: bilinmeyen durum ve boş isimler
        try (Statement st = connection.createStatement()) {
            st.execute("UPDATE reports SET status = 'GARBAGE', reported_uuid = 'not-a-uuid' WHERE id = 1");
        }
        Report loaded = storage.getById(1).orElseThrow();
        assertEquals(ReportStatus.ACTIVE, loaded.status()); // bilinmeyen durum ACTIVE'e düşer
        assertEquals(1, storage.getPage(null, 0, 10, false).size());
    }

    @Test
    void cacheServesRepeatedReadsAndRespectsInvalidation() throws Exception {
        long[] now = {1_000L};
        ReportCache cache = new ReportCache(true, 8, 30, () -> now[0]);
        storage.insert(draft(STEVE, "Steve", ALEX, "a"));

        assertArrayEquals(new int[]{1, 0, 0}, cache.statusCounts(storage));
        assertArrayEquals(new int[]{1, 1, 0, 0}, cache.targetCounts(storage, STEVE, "Steve"));
        long missesAfterFirstRead = cache.misses();

        // yeni rapor eklenir ama önbellek geçersiz kılınmadı: eski değer (kontrollü) görünür
        storage.insert(draft(STEVE, "Steve", NOTCH, "b"));
        assertArrayEquals(new int[]{1, 0, 0}, cache.statusCounts(storage));
        assertEquals(missesAfterFirstRead, cache.misses());
        assertTrue(cache.hits() >= 1);

        // invalidate sonrası güncel değer okunur
        cache.invalidate();
        assertArrayEquals(new int[]{2, 0, 0}, cache.statusCounts(storage));
        assertArrayEquals(new int[]{2, 2, 0, 0}, cache.targetCounts(storage, STEVE, "Steve"));
    }

    @Test
    void cacheEntriesExpireAfterTtlAndAreBounded() throws Exception {
        long[] now = {0L};
        ReportCache cache = new ReportCache(true, 2, 10, () -> now[0]);
        storage.insert(draft(STEVE, "Steve", ALEX, "a"));
        assertArrayEquals(new int[]{1, 1, 0, 0}, cache.targetCounts(storage, STEVE, "Steve"));

        storage.insert(draft(STEVE, "Steve", NOTCH, "b"));
        now[0] = 5_000L; // TTL (10 sn) dolmadı
        assertArrayEquals(new int[]{1, 1, 0, 0}, cache.targetCounts(storage, STEVE, "Steve"));
        now[0] = 11_000L; // TTL doldu
        assertArrayEquals(new int[]{2, 2, 0, 0}, cache.targetCounts(storage, STEVE, "Steve"));

        // en fazla 2 oyuncu tutulur
        cache.targetCounts(storage, NOTCH, "Notch");
        cache.targetCounts(storage, ALEX, "Alex");
        cache.targetCounts(storage, "44444444-4444-4444-4444-444444444444", "Four");
        assertTrue(cache.size() <= 2, "size=" + cache.size());
    }

    @Test
    void disabledCacheAlwaysReadsFresh() throws Exception {
        ReportCache cache = new ReportCache(false, 8, 30);
        storage.insert(draft(STEVE, "Steve", ALEX, "a"));
        assertArrayEquals(new int[]{1, 0, 0}, cache.statusCounts(storage));
        storage.insert(draft(STEVE, "Steve", NOTCH, "b"));
        assertArrayEquals(new int[]{2, 0, 0}, cache.statusCounts(storage));
        assertEquals(0, cache.size());
    }

    @Test
    void migrationUpgradesV1DatabaseWithoutLosingReports() throws Exception {
        File v1File = dir.resolve("v1.db").toFile();
        try (Connection c = DriverManager.getConnection("jdbc:sqlite:" + v1File.getAbsolutePath());
             Statement st = c.createStatement()) {
            // V1 şeması (9 sütun, user_version = 0)
            st.execute("CREATE TABLE reports (id INTEGER PRIMARY KEY AUTOINCREMENT, reported_name TEXT NOT NULL, "
                    + "reported_uuid TEXT, reporter_name TEXT NOT NULL, reporter_uuid TEXT NOT NULL, reason TEXT NOT NULL, "
                    + "report_date TEXT NOT NULL, report_time TEXT NOT NULL, timestamp INTEGER NOT NULL)");
            st.execute("INSERT INTO reports (reported_name, reported_uuid, reporter_name, reporter_uuid, reason, "
                    + "report_date, report_time, timestamp) VALUES ('Steve', '" + STEVE + "', 'Alex', '" + ALEX
                    + "', 'Hile kullanıyor', '07.11.2026', '21:45', 1762548300000)");
            st.execute("INSERT INTO reports (reported_name, reported_uuid, reporter_name, reporter_uuid, reason, "
                    + "report_date, report_time, timestamp) VALUES ('Notch', NULL, 'Player123', '" + NOTCH
                    + "', 'Küfür ediyor', '07.11.2026', '21:52', 1762548720000)");
        }

        try (Connection c = DriverManager.getConnection("jdbc:sqlite:" + v1File.getAbsolutePath())) {
            assertTrue(DatabaseMigration.run(c, v1File, LOG), "V1 -> V2 yükseltmesi true dönmeli");
            SQLiteStorage migrated = new SQLiteStorage(c);

            List<Report> all = migrated.getPage(null, 0, 10, false);
            assertEquals(2, all.size());
            assertEquals("Hile kullanıyor", all.get(0).reason());
            assertEquals(ReportStatus.ACTIVE, all.get(0).status());
            assertFalse(all.get(0).evidence());
            assertEquals(1762548300000L, all.get(0).timestamp());
            assertEquals("Notch", all.get(1).reportedName());

            try (Statement st = c.createStatement();
                 ResultSet rs = st.executeQuery("PRAGMA user_version")) {
                assertTrue(rs.next());
                assertEquals(DatabaseMigration.SCHEMA_VERSION, rs.getInt(1));
            }
            // yükseltilmiş veritabanına yeni rapor yazılabilir ve ID devam eder
            assertEquals(3, migrated.insert(draft(STEVE, "Steve", ALEX, "yeni")).id());

            // ikinci çalıştırma güvenli (idempotent) ve false döner
            assertFalse(DatabaseMigration.run(c, v1File, LOG));
            assertEquals(3, migrated.getPage(null, 0, 10, false).size());
        }
        assertTrue(new File(dir.toFile(), "reports-v1-backup.db").exists(), "V1 yedeği alınmalı");
    }

    private static List<Integer> ids(List<Report> reports) {
        return reports.stream().map(Report::id).toList();
    }
}
