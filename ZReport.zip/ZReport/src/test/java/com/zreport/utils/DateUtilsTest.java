package com.zreport.utils;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class DateUtilsTest {

    @Test
    void compactDurations() {
        assertEquals("1d", DateUtils.compact(86400));
        assertEquals("30d", DateUtils.compact(30L * 86400));
        assertEquals("6h", DateUtils.compact(6 * 3600));
        assertEquals("30m", DateUtils.compact(1800));
        assertEquals("1m", DateUtils.compact(10));
    }

    @Test
    void humanDurations() {
        assertEquals("-", DateUtils.human(0));
        assertEquals("1 gün 1 saat 1 dakika", DateUtils.human(86400 + 3600 + 60));
        assertEquals("7 gün", DateUtils.human(7L * 86400));
        assertEquals("6 saat", DateUtils.human(6 * 3600));
    }

    @Test
    void zeroOrNegativeTimestampsRenderAsDash() {
        assertEquals("-", DateUtils.date(0));
        assertEquals("-", DateUtils.dateTime(-5));
    }
}
