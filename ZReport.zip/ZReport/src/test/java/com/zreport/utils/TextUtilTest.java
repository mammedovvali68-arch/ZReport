package com.zreport.utils;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class TextUtilTest {

    @Test
    void sanitizeRemovesSectionSignsControlCharsAndExtraSpaces() {
        assertEquals("a c b c", TextUtil.sanitize("  a\u00A7c   b\tc  \n"));
        assertEquals("", TextUtil.sanitize(null));
        assertEquals("", TextUtil.sanitize("   "));
    }

    @Test
    void hasLetterOrDigit() {
        assertTrue(TextUtil.hasLetterOrDigit("!!a!!"));
        assertTrue(TextUtil.hasLetterOrDigit("..9"));
        assertFalse(TextUtil.hasLetterOrDigit("!!! ???"));
    }

    @Test
    void fillReplacesKnownPlaceholders() {
        assertEquals("Merhaba Steve, rapor #5", TextUtil.fill("Merhaba %player%, rapor #%id%", "player", "Steve", "id", "5"));
    }

    @Test
    void fillLeavesUnknownPlaceholdersAndLonePercentSigns() {
        assertEquals("%unknown% 50% off", TextUtil.fill("%unknown% 50% off", "player", "x"));
        assertEquals("100% Steve", TextUtil.fill("100% %player%", "player", "Steve"));
    }

    @Test
    void fillDoesNotExpandPlaceholdersInsideInsertedValues() {
        // Kullanıcı girdisi başka bir yer tutucuyu tetikleyememeli.
        assertEquals("Sebep: %reporter% / Alex", TextUtil.fill("Sebep: %reason% / %reporter%", "reason", "%reporter%", "reporter", "Alex"));
    }

    @Test
    void fillTreatsNullValueAsEmpty() {
        assertEquals("[]", TextUtil.fill("[%x%]", "x", null));
    }

    @Test
    void wrapSplitsLongTextAndHardSplitsLongWords() {
        List<String> lines = TextUtil.wrap("one two three four five six", 10);
        assertTrue(lines.size() >= 3);
        for (String line : lines) {
            assertTrue(line.length() <= 10, line);
        }
        List<String> hard = TextUtil.wrap("abcdefghijklmnopqrstuvwxyz", 10);
        assertEquals(List.of("abcdefghij", "klmnopqrst", "uvwxyz"), hard);
        assertEquals(List.of(""), TextUtil.wrap("", 10));
    }
}
