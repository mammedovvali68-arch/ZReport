package com.zreport.utils;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class CommandUtilsTest {

    @Test
    void parsesValidIds() {
        assertEquals(12, CommandUtils.parseReportId("12"));
        assertEquals(7, CommandUtils.parseReportId("#7"));
    }

    @Test
    void rejectsInvalidIds() {
        assertEquals(-1, CommandUtils.parseReportId("0"));
        assertEquals(-1, CommandUtils.parseReportId("-3"));
        assertEquals(-1, CommandUtils.parseReportId("abc"));
        assertEquals(-1, CommandUtils.parseReportId("99999999999"));
        assertEquals(-1, CommandUtils.parseReportId(""));
        assertEquals(-1, CommandUtils.parseReportId(null));
    }
}
