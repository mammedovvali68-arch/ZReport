package com.zreport.models;

/** Bir ceza isteğini taşır. durationSeconds yalnızca TEMPBAN için anlamlıdır. */
public record Punishment(PunishmentType type, String reason, long durationSeconds,
                         String targetUuid, String targetName, String staffName) {
}
