package com.zreport.models;

public enum ReportStatus {
    ACTIVE, REVIEWED, PUNISHED;

    public static ReportStatus fromString(String value) {
        if (value != null) {
            for (ReportStatus status : values()) {
                if (status.name().equalsIgnoreCase(value)) {
                    return status;
                }
            }
        }
        return ACTIVE;
    }
}
