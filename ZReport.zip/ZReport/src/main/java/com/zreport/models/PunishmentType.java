package com.zreport.models;

public enum PunishmentType {
    WARNING, KICK, TEMPBAN, PERMBAN, OTHER;

    public static PunishmentType fromString(String value) {
        if (value != null) {
            for (PunishmentType type : values()) {
                if (type.name().equalsIgnoreCase(value)) {
                    return type;
                }
            }
        }
        return null;
    }
}
