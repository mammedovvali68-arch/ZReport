package com.zreport.models;

import java.util.List;

/** Bir sayfa rapor ve sayfalama bilgisi. */
public record ReportPage(List<Report> reports, int page, int totalPages, int totalCount) {
}
