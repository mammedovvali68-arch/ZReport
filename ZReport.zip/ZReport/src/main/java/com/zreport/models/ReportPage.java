package com.zreport.models;

import java.util.List;
import java.util.Map;

/**
 * Bir sayfa rapor. targetTotals: rapor ID -> raporlanan oyuncunun toplam rapor sayısı.
 * counts: [ACTIVE, REVIEWED, PUNISHED] toplamları.
 */
public record ReportPage(List<Report> reports, int page, int totalPages, int totalCount,
                         Map<Integer, Integer> targetTotals, int[] counts) {
}
