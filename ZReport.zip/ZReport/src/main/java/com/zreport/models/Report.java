package com.zreport.models;

import com.zreport.utils.DateUtils;

/** Değiştirilemez rapor modeli. Her rapor ayrı bir kayıttır. */
public record Report(
        int id,
        String reportedName,
        String reportedUuid,
        String reporterName,
        String reporterUuid,
        String reason,
        String date,
        String time,
        long timestamp,
        boolean evidence,
        ReportStatus status,
        String reviewedByUuid,
        String reviewedByName,
        long reviewedAt,
        String reviewNote,
        String punishmentType,
        String punishmentReason,
        long punishmentDuration,
        String punishedByUuid,
        String punishedByName,
        long punishedAt) {

    public static Report create(String reportedName, String reportedUuid, String reporterName,
                                String reporterUuid, String reason, boolean evidence) {
        long now = System.currentTimeMillis();
        return new Report(0, reportedName, reportedUuid, reporterName, reporterUuid, reason,
                DateUtils.date(now), DateUtils.time(now), now, evidence, ReportStatus.ACTIVE,
                null, null, 0, null, null, null, 0, null, null, 0);
    }

    public Report withId(int newId) {
        return new Report(newId, reportedName, reportedUuid, reporterName, reporterUuid, reason, date, time,
                timestamp, evidence, status, reviewedByUuid, reviewedByName, reviewedAt, reviewNote,
                punishmentType, punishmentReason, punishmentDuration, punishedByUuid, punishedByName, punishedAt);
    }
}
