package com.zreport.models;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** Değiştirilemez rapor modeli. Tarih/saat sunucunun yerel saatine göre kaydedilir. */
public record Report(
        int id,
        String reportedName,
        String reportedUuid,
        String reporterName,
        String reporterUuid,
        String reason,
        String date,
        String time,
        long timestamp) {

    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("HH:mm");

    public static Report create(String reportedName, String reportedUuid,
                                String reporterName, String reporterUuid, String reason) {
        LocalDateTime now = LocalDateTime.now();
        return new Report(0, reportedName, reportedUuid, reporterName, reporterUuid, reason,
                DATE_FORMAT.format(now), TIME_FORMAT.format(now), System.currentTimeMillis());
    }

    public Report withId(int newId) {
        return new Report(newId, reportedName, reportedUuid, reporterName, reporterUuid, reason, date, time, timestamp);
    }

    public Report withReason(String newReason) {
        return new Report(id, reportedName, reportedUuid, reporterName, reporterUuid, newReason, date, time, timestamp);
    }
}
