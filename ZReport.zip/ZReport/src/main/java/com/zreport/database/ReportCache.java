package com.zreport.database;

import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.function.LongSupplier;

/**
 * Sınırlı boyutlu (LRU) ve süreli sayaç önbelleği.
 * Her yazma işlemi invalidate() çağırır, bu yüzden eski sayı gösterilmez; TTL ek güvenliktir.
 * Yalnızca veritabanı thread'inden kullanılır, yine de metotlar senkronizedir.
 */
public final class ReportCache {

    private record Entry(int[] values, long expiresAt) {
    }

    private final boolean enabled;
    private final long ttlMillis;
    private final LongSupplier clock;
    private final Map<String, Entry> targets;
    private Entry statuses;
    private long hits;
    private long misses;

    public ReportCache(boolean enabled, int maxEntries, long ttlSeconds) {
        this(enabled, maxEntries, ttlSeconds, System::currentTimeMillis);
    }

    ReportCache(boolean enabled, int maxEntries, long ttlSeconds, LongSupplier clock) {
        this.enabled = enabled;
        this.ttlMillis = Math.max(1, ttlSeconds) * 1000L;
        this.clock = clock;
        final int limit = Math.max(1, maxEntries);
        this.targets = new LinkedHashMap<>(16, 0.75f, true) {
            @Override
            protected boolean removeEldestEntry(Map.Entry<String, Entry> eldest) {
                return size() > limit;
            }
        };
    }

    /** [ACTIVE, REVIEWED, PUNISHED] */
    public synchronized int[] statusCounts(SQLiteStorage storage) throws SQLException {
        long now = clock.getAsLong();
        if (enabled && statuses != null && statuses.expiresAt() > now) {
            hits++;
            return statuses.values().clone();
        }
        misses++;
        int[] fresh = storage.statusCounts();
        if (enabled) {
            statuses = new Entry(fresh.clone(), now + ttlMillis);
        }
        return fresh;
    }

    /** [toplam, aktif, incelenmiş, cezalı] */
    public synchronized int[] targetCounts(SQLiteStorage storage, String uuid, String name) throws SQLException {
        String key = uuid != null ? "u:" + uuid : "n:" + name.toLowerCase(Locale.ROOT);
        long now = clock.getAsLong();
        Entry cached = enabled ? targets.get(key) : null;
        if (cached != null && cached.expiresAt() > now) {
            hits++;
            return cached.values().clone();
        }
        misses++;
        int[] fresh = storage.targetCounts(uuid, name);
        if (enabled) {
            targets.put(key, new Entry(fresh.clone(), now + ttlMillis));
        }
        return fresh;
    }

    public synchronized void invalidate() {
        statuses = null;
        targets.clear();
    }

    public synchronized int size() {
        return targets.size() + (statuses != null ? 1 : 0);
    }

    public synchronized long hits() {
        return hits;
    }

    public synchronized long misses() {
        return misses;
    }
}
