package com.zreport.database;

import com.zreport.utils.Log;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;

/**
 * V1 -> V2 şema geçişi. Mevcut raporlar silinmez; eksik sütunlar eklenir ve
 * eski raporlar varsayılan olarak ACTIVE / kanıtsız olarak işaretlenir.
 * V1 veritabanı geçişten önce reports-v1-backup.db olarak yedeklenir.
 */
public final class DatabaseMigration {

    public static final int SCHEMA_VERSION = 2;

    private DatabaseMigration() {
    }

    /** Şemayı oluşturur/yükseltir. V1'den gerçek bir yükseltme yapıldıysa true döner. */
    public static boolean run(Connection connection, File dbFile, Logger logger) throws SQLException {
        try (Statement st = connection.createStatement()) {
            st.execute("PRAGMA journal_mode=WAL");
            st.execute("PRAGMA synchronous=NORMAL");
            st.execute("PRAGMA busy_timeout=5000");
            st.execute("PRAGMA temp_store=MEMORY");
        }
        boolean tableExists = tableExists(connection);
        int version = userVersion(connection);

        if (tableExists && version < SCHEMA_VERSION) {
            backup(connection, dbFile, logger);
        }
        try (Statement st = connection.createStatement()) {
            st.execute("CREATE TABLE IF NOT EXISTS reports ("
                    + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "reported_name TEXT NOT NULL,"
                    + "reported_uuid TEXT,"
                    + "reporter_name TEXT NOT NULL,"
                    + "reporter_uuid TEXT NOT NULL,"
                    + "reason TEXT NOT NULL,"
                    + "report_date TEXT NOT NULL,"
                    + "report_time TEXT NOT NULL,"
                    + "timestamp INTEGER NOT NULL,"
                    + "evidence INTEGER NOT NULL DEFAULT 0,"
                    + "status TEXT NOT NULL DEFAULT 'ACTIVE',"
                    + "reviewed_by_uuid TEXT,"
                    + "reviewed_by_name TEXT,"
                    + "reviewed_at INTEGER NOT NULL DEFAULT 0,"
                    + "review_note TEXT,"
                    + "punishment_type TEXT,"
                    + "punishment_reason TEXT,"
                    + "punishment_duration INTEGER NOT NULL DEFAULT 0,"
                    + "punished_by_uuid TEXT,"
                    + "punished_by_name TEXT,"
                    + "punished_at INTEGER NOT NULL DEFAULT 0)");
        }
        addMissingColumns(connection, logger);
        try (Statement st = connection.createStatement()) {
            // Liste sayfaları: WHERE status = ? ORDER BY id LIMIT ? (tam eşleşen kapsayıcı indeks)
            st.execute("CREATE INDEX IF NOT EXISTS idx_reports_status_id ON reports(status, id)");
            // Oyuncu geçmişi ve toplam rapor sayısı (UUID ile)
            st.execute("CREATE INDEX IF NOT EXISTS idx_reports_target_uuid ON reports(reported_uuid, id)");
            // UUID'si bilinmeyen (çevrimdışı) hedefler için isimle arama
            st.execute("CREATE INDEX IF NOT EXISTS idx_reports_target_name ON reports(reported_name COLLATE NOCASE) "
                    + "WHERE reported_uuid IS NULL");
            // Tekrar rapor kontrolü
            st.execute("CREATE INDEX IF NOT EXISTS idx_reports_reporter_status ON reports(reporter_uuid, status)");
            // V2'de kullanılan eski indeksler artık gereksiz
            st.execute("DROP INDEX IF EXISTS idx_reports_timestamp");
            st.execute("DROP INDEX IF EXISTS idx_reports_status");
            st.execute("DROP INDEX IF EXISTS idx_reports_reported_uuid");
            st.execute("PRAGMA user_version=" + SCHEMA_VERSION);
        }
        boolean upgraded = tableExists && version < SCHEMA_VERSION;
        if (upgraded) {
            logger.info("Database upgraded to the V2 schema. Existing reports were preserved.");
        }
        return upgraded;
    }

    private static void addMissingColumns(Connection connection, Logger logger) throws SQLException {
        Map<String, String> wanted = new LinkedHashMap<>();
        wanted.put("evidence", "INTEGER NOT NULL DEFAULT 0");
        wanted.put("status", "TEXT NOT NULL DEFAULT 'ACTIVE'");
        wanted.put("reviewed_by_uuid", "TEXT");
        wanted.put("reviewed_by_name", "TEXT");
        wanted.put("reviewed_at", "INTEGER NOT NULL DEFAULT 0");
        wanted.put("review_note", "TEXT");
        wanted.put("punishment_type", "TEXT");
        wanted.put("punishment_reason", "TEXT");
        wanted.put("punishment_duration", "INTEGER NOT NULL DEFAULT 0");
        wanted.put("punished_by_uuid", "TEXT");
        wanted.put("punished_by_name", "TEXT");
        wanted.put("punished_at", "INTEGER NOT NULL DEFAULT 0");

        Set<String> existing = new HashSet<>();
        try (Statement st = connection.createStatement();
             ResultSet rs = st.executeQuery("PRAGMA table_info(reports)")) {
            while (rs.next()) {
                existing.add(rs.getString("name").toLowerCase());
            }
        }
        for (Map.Entry<String, String> column : wanted.entrySet()) {
            if (!existing.contains(column.getKey())) {
                try (Statement st = connection.createStatement()) {
                    // Sütun adları ve tanımlar sabittir, kullanıcı girdisi içermez.
                    st.execute("ALTER TABLE reports ADD COLUMN " + column.getKey() + " " + column.getValue());
                }
                Log.debug("Added database column: " + column.getKey());
            }
        }
    }

    private static boolean tableExists(Connection connection) throws SQLException {
        try (Statement st = connection.createStatement();
             ResultSet rs = st.executeQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='reports'")) {
            return rs.next();
        }
    }

    private static int userVersion(Connection connection) throws SQLException {
        try (Statement st = connection.createStatement();
             ResultSet rs = st.executeQuery("PRAGMA user_version")) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    private static void backup(Connection connection, File dbFile, Logger logger) {
        File backup = new File(dbFile.getParentFile(), "reports-v1-backup.db");
        if (backup.exists()) {
            return;
        }
        try (Statement st = connection.createStatement()) {
            st.execute("PRAGMA wal_checkpoint(TRUNCATE)");
        } catch (SQLException ex) {
            logger.warning("WAL checkpoint failed: " + ex.getMessage());
        }
        try {
            Files.copy(dbFile.toPath(), backup.toPath(), StandardCopyOption.COPY_ATTRIBUTES);
            logger.info("V1 database backed up as " + backup.getName());
        } catch (IOException ex) {
            logger.warning("V1 backup could not be created: " + ex.getMessage());
        }
    }
}
