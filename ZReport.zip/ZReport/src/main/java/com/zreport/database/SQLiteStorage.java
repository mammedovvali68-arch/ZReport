package com.zreport.database;

import com.zreport.models.Report;
import com.zreport.models.ReportStatus;
import com.zreport.utils.Log;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * SQLite erişim katmanı. Tek kalıcı bağlantı kullanır, bütün sorgular PreparedStatement'tır.
 * Yalnızca DatabaseManager'ın tek iş parçacıklı executor'ı üzerinden çağrılır.
 */
public class SQLiteStorage {

    private static final String COLUMNS = "id, reported_name, reported_uuid, reporter_name, reporter_uuid, "
            + "reason, report_date, report_time, timestamp, evidence, status, reviewed_by_uuid, reviewed_by_name, "
            + "reviewed_at, review_note, punishment_type, punishment_reason, punishment_duration, "
            + "punished_by_uuid, punished_by_name, punished_at";

    private final Connection connection;

    public SQLiteStorage(Connection connection) {
        this.connection = connection;
    }

    public synchronized boolean isUsable() {
        try {
            return !connection.isClosed();
        } catch (SQLException ex) {
            return false;
        }
    }

    // ---------------------------------------------------------------- yazma

    public synchronized Report insert(Report report) throws SQLException {
        String sql = "INSERT INTO reports (reported_name, reported_uuid, reporter_name, reporter_uuid, reason, "
                + "report_date, report_time, timestamp, evidence, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, report.reportedName());
            ps.setString(2, report.reportedUuid());
            ps.setString(3, report.reporterName());
            ps.setString(4, report.reporterUuid());
            ps.setString(5, report.reason());
            ps.setString(6, report.date());
            ps.setString(7, report.time());
            ps.setLong(8, report.timestamp());
            ps.setInt(9, report.evidence() ? 1 : 0);
            ps.setString(10, report.status().name());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    return report.withId(keys.getInt(1));
                }
            }
        }
        throw new SQLException("Rapor ID'si alınamadı.");
    }

    /** Aynı raporlayanın aynı hedefe karşı hâlâ ACTIVE bir raporu var mı? */
    public synchronized boolean existsActive(String reporterUuid, String reportedUuid, String reportedName)
            throws SQLException {
        String sql = "SELECT 1 FROM reports WHERE status = 'ACTIVE' AND reporter_uuid = ? AND "
                + targetClause(reportedUuid) + " LIMIT 1";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, reporterUuid);
            bindTarget(ps, 2, reportedUuid, reportedName);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    /** ACTIVE raporu REVIEWED yapar. Rapor yoksa veya zaten işlenmişse false döner. */
    public synchronized boolean markReviewed(int id, String byUuid, String byName, String note, long at)
            throws SQLException {
        if (id <= 0) {
            return false;
        }
        String sql = "UPDATE reports SET status = 'REVIEWED', reviewed_by_uuid = ?, reviewed_by_name = ?, "
                + "reviewed_at = ?, review_note = ? WHERE id = ? AND status = 'ACTIVE'";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, byUuid);
            ps.setString(2, byName);
            ps.setLong(3, at);
            ps.setString(4, note);
            ps.setInt(5, id);
            return ps.executeUpdate() > 0;
        }
    }

    /** Raporu PUNISHED yapar. Rapor yoksa veya zaten cezalandırılmışsa false döner. */
    public synchronized boolean markPunished(int id, String type, String reason, long duration,
                                             String byUuid, String byName, long at) throws SQLException {
        if (id <= 0) {
            return false;
        }
        String sql = "UPDATE reports SET status = 'PUNISHED', punishment_type = ?, punishment_reason = ?, "
                + "punishment_duration = ?, punished_by_uuid = ?, punished_by_name = ?, punished_at = ? "
                + "WHERE id = ? AND status <> 'PUNISHED'";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, type);
            ps.setString(2, reason);
            ps.setLong(3, duration);
            ps.setString(4, byUuid);
            ps.setString(5, byName);
            ps.setLong(6, at);
            ps.setInt(7, id);
            return ps.executeUpdate() > 0;
        }
    }

    public synchronized boolean delete(int id) throws SQLException {
        if (id <= 0) {
            return false;
        }
        try (PreparedStatement ps = connection.prepareStatement("DELETE FROM reports WHERE id = ?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    /** Tüm raporları siler ve ID sayacını sıfırlar; iki adım tek transaction içindedir. */
    public synchronized int clear() throws SQLException {
        boolean previousAutoCommit = connection.getAutoCommit();
        connection.setAutoCommit(false);
        try {
            int removed;
            try (PreparedStatement ps = connection.prepareStatement("DELETE FROM reports")) {
                removed = ps.executeUpdate();
            }
            try (PreparedStatement ps = connection.prepareStatement("DELETE FROM sqlite_sequence WHERE name = ?")) {
                ps.setString(1, "reports");
                ps.executeUpdate();
            }
            connection.commit();
            return removed;
        } catch (SQLException ex) {
            try {
                connection.rollback();
            } catch (SQLException rollbackFailure) {
                ex.addSuppressed(rollbackFailure);
            }
            throw ex;
        } finally {
            connection.setAutoCommit(previousAutoCommit);
        }
    }

    // ---------------------------------------------------------------- okuma

    /** [ACTIVE, REVIEWED, PUNISHED] sayıları. */
    public synchronized int[] statusCounts() throws SQLException {
        int[] counts = new int[3];
        try (PreparedStatement ps = connection.prepareStatement("SELECT status, COUNT(*) FROM reports GROUP BY status");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                counts[ReportStatus.fromString(rs.getString(1)).ordinal()] += rs.getInt(2);
            }
        }
        return counts;
    }

    public synchronized List<Report> getPage(ReportStatus status, int offset, int limit, boolean newestFirst)
            throws SQLException {
        String sql = "SELECT " + COLUMNS + " FROM reports" + (status != null ? " WHERE status = ?" : "")
                + " ORDER BY id " + (newestFirst ? "DESC" : "ASC") + " LIMIT ? OFFSET ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            int index = 1;
            if (status != null) {
                ps.setString(index++, status.name());
            }
            ps.setInt(index++, limit);
            ps.setInt(index, offset);
            return readAll(ps);
        }
    }

    public synchronized Optional<Report> getById(int id) throws SQLException {
        if (id <= 0) {
            return Optional.empty();
        }
        try (PreparedStatement ps = connection.prepareStatement("SELECT " + COLUMNS + " FROM reports WHERE id = ?")) {
            ps.setInt(1, id);
            List<Report> rows = readAll(ps);
            return rows.isEmpty() ? Optional.empty() : Optional.of(rows.get(0));
        }
    }

    /** Hedef oyuncunun raporları: [toplam, aktif, incelenmiş, cezalı]. UUID biliniyorsa UUID ile eşleşir. */
    public synchronized int[] targetCounts(String uuid, String name) throws SQLException {
        int[] result = new int[4];
        String sql = "SELECT status, COUNT(*) FROM reports WHERE " + targetClause(uuid) + " GROUP BY status";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            bindTarget(ps, 1, uuid, name);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    int count = rs.getInt(2);
                    result[0] += count;
                    result[1 + ReportStatus.fromString(rs.getString(1)).ordinal()] += count;
                }
            }
        }
        return result;
    }

    /**
     * Bir sayfadaki raporların hedeflerinin toplam rapor sayısı (rapor ID -> sayı).
     * Hedef başına sorgu yerine en fazla iki gruplu sorgu çalışır.
     */
    public synchronized Map<Integer, Integer> targetTotals(List<Report> reports) throws SQLException {
        Set<String> uuids = new LinkedHashSet<>();
        Set<String> names = new LinkedHashSet<>();
        for (Report report : reports) {
            if (report.reportedUuid() != null) {
                uuids.add(report.reportedUuid());
            } else {
                names.add(report.reportedName().toLowerCase(Locale.ROOT));
            }
        }
        Map<String, Integer> uuidCounts = new HashMap<>();
        Map<String, Integer> nameCounts = new HashMap<>();
        if (!uuids.isEmpty()) {
            String sql = "SELECT reported_uuid, COUNT(*) FROM reports WHERE reported_uuid IN ("
                    + placeholders(uuids.size()) + ") GROUP BY reported_uuid";
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                int index = 1;
                for (String uuid : uuids) {
                    ps.setString(index++, uuid);
                }
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        uuidCounts.put(rs.getString(1), rs.getInt(2));
                    }
                }
            }
        }
        if (!names.isEmpty()) {
            String sql = "SELECT lower(reported_name), COUNT(*) FROM reports WHERE reported_uuid IS NULL AND "
                    + "reported_name COLLATE NOCASE IN (" + placeholders(names.size()) + ") GROUP BY lower(reported_name)";
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                int index = 1;
                for (String name : names) {
                    ps.setString(index++, name);
                }
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        nameCounts.put(rs.getString(1), rs.getInt(2));
                    }
                }
            }
        }
        Map<Integer, Integer> totals = new HashMap<>();
        for (Report report : reports) {
            Integer count = report.reportedUuid() != null
                    ? uuidCounts.get(report.reportedUuid())
                    : nameCounts.get(report.reportedName().toLowerCase(Locale.ROOT));
            totals.put(report.id(), count == null ? 1 : count);
        }
        return totals;
    }

    public synchronized List<Report> targetPage(String uuid, String name, int offset, int limit)
            throws SQLException {
        String sql = "SELECT " + COLUMNS + " FROM reports WHERE " + targetClause(uuid)
                + " ORDER BY id DESC LIMIT ? OFFSET ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            int next = bindTarget(ps, 1, uuid, name);
            ps.setInt(next, limit);
            ps.setInt(next + 1, offset);
            return readAll(ps);
        }
    }

    public synchronized void close() {
        try {
            if (!connection.isClosed()) {
                try (Statement st = connection.createStatement()) {
                    st.execute("PRAGMA optimize");
                } catch (SQLException ignored) {
                    // optimize başarısız olsa da bağlantı kapatılır
                }
                connection.close();
            }
        } catch (SQLException ex) {
            Log.warn("Database connection could not be closed cleanly: " + ex.getMessage());
        }
    }

    // ------------------------------------------------------------ yardımcılar

    private static String placeholders(int count) {
        StringBuilder sb = new StringBuilder(count * 2);
        for (int i = 0; i < count; i++) {
            sb.append(i == 0 ? "?" : ",?");
        }
        return sb.toString();
    }

    private static String targetClause(String uuid) {
        return uuid != null ? "reported_uuid = ?" : "(reported_uuid IS NULL AND reported_name = ? COLLATE NOCASE)";
    }

    /** Hedef parametresini bağlar; bir sonraki parametre indeksini döndürür. */
    private static int bindTarget(PreparedStatement ps, int index, String uuid, String name) throws SQLException {
        ps.setString(index, uuid != null ? uuid : name);
        return index + 1;
    }

    /** Bozuk bir satır bütün listeyi düşürmesin diye satırlar tek tek okunur. */
    private List<Report> readAll(PreparedStatement ps) throws SQLException {
        List<Report> list = new ArrayList<>();
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Report report = mapSafely(rs);
                if (report != null) {
                    list.add(report);
                }
            }
        }
        return list;
    }

    private Report mapSafely(ResultSet rs) {
        try {
            return new Report(
                    rs.getInt("id"),
                    orDefault(rs.getString("reported_name"), "?"),
                    rs.getString("reported_uuid"),
                    orDefault(rs.getString("reporter_name"), "?"),
                    rs.getString("reporter_uuid"),
                    orDefault(rs.getString("reason"), "-"),
                    orDefault(rs.getString("report_date"), "-"),
                    orDefault(rs.getString("report_time"), "-"),
                    rs.getLong("timestamp"),
                    rs.getInt("evidence") == 1,
                    ReportStatus.fromString(rs.getString("status")),
                    rs.getString("reviewed_by_uuid"),
                    rs.getString("reviewed_by_name"),
                    rs.getLong("reviewed_at"),
                    rs.getString("review_note"),
                    rs.getString("punishment_type"),
                    rs.getString("punishment_reason"),
                    rs.getLong("punishment_duration"),
                    rs.getString("punished_by_uuid"),
                    rs.getString("punished_by_name"),
                    rs.getLong("punished_at"));
        } catch (SQLException ex) {
            Log.warn("Skipping a corrupt report row: " + ex.getMessage());
            return null;
        }
    }

    private static String orDefault(String value, String fallback) {
        return value == null ? fallback : value;
    }
}
