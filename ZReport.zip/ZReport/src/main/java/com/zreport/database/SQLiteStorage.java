package com.zreport.database;

import com.zreport.models.Report;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * SQLite erişim katmanı. Tüm sorgular PreparedStatement kullanır.
 * Bu sınıf yalnızca DatabaseManager'ın tek iş parçacıklı executor'ı üzerinden çağrılır.
 */
public class SQLiteStorage {

    private static final String COLUMNS =
            "id, reported_name, reported_uuid, reporter_name, reporter_uuid, reason, report_date, report_time, timestamp";

    private final Connection connection;

    public SQLiteStorage(Connection connection) {
        this.connection = connection;
    }

    public synchronized void initialize() throws SQLException {
        try (Statement st = connection.createStatement()) {
            st.execute("PRAGMA journal_mode=WAL");
            st.execute("PRAGMA busy_timeout=5000");
            st.execute("CREATE TABLE IF NOT EXISTS reports ("
                    + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "reported_name TEXT NOT NULL,"
                    + "reported_uuid TEXT,"
                    + "reporter_name TEXT NOT NULL,"
                    + "reporter_uuid TEXT NOT NULL,"
                    + "reason TEXT NOT NULL,"
                    + "report_date TEXT NOT NULL,"
                    + "report_time TEXT NOT NULL,"
                    + "timestamp INTEGER NOT NULL)");
            st.execute("CREATE INDEX IF NOT EXISTS idx_reports_timestamp ON reports(timestamp)");
        }
    }

    public synchronized Report insert(Report report) throws SQLException {
        String sql = "INSERT INTO reports (reported_name, reported_uuid, reporter_name, reporter_uuid, "
                + "reason, report_date, report_time, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, report.reportedName());
            ps.setString(2, report.reportedUuid());
            ps.setString(3, report.reporterName());
            ps.setString(4, report.reporterUuid());
            ps.setString(5, report.reason());
            ps.setString(6, report.date());
            ps.setString(7, report.time());
            ps.setLong(8, report.timestamp());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    return report.withId(keys.getInt(1));
                }
            }
        }
        throw new SQLException("Rapor ID'si alınamadı.");
    }

    public synchronized int count() throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement("SELECT COUNT(*) FROM reports");
             ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    public synchronized List<Report> getPage(int offset, int limit, boolean newestFirst) throws SQLException {
        String order = newestFirst ? "DESC" : "ASC"; // sabit değer, kullanıcı girdisi değil
        String sql = "SELECT " + COLUMNS + " FROM reports ORDER BY id " + order + " LIMIT ? OFFSET ?";
        List<Report> list = new ArrayList<>();
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, limit);
            ps.setInt(2, offset);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }
        }
        return list;
    }

    public synchronized Optional<Report> getById(int id) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement("SELECT " + COLUMNS + " FROM reports WHERE id = ?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(map(rs)) : Optional.empty();
            }
        }
    }

    public synchronized boolean delete(int id) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement("DELETE FROM reports WHERE id = ?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    /** Tüm raporları siler ve ID sayacını sıfırlar. Silinen kayıt sayısını döndürür. */
    public synchronized int clear() throws SQLException {
        int removed;
        try (PreparedStatement ps = connection.prepareStatement("DELETE FROM reports")) {
            removed = ps.executeUpdate();
        }
        try (PreparedStatement ps = connection.prepareStatement("DELETE FROM sqlite_sequence WHERE name = ?")) {
            ps.setString(1, "reports");
            ps.executeUpdate();
        }
        return removed;
    }

    public synchronized void close() {
        try {
            if (!connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException ignored) {
            // kapanırken oluşan hata önemsiz
        }
    }

    private Report map(ResultSet rs) throws SQLException {
        return new Report(
                rs.getInt("id"),
                rs.getString("reported_name"),
                rs.getString("reported_uuid"),
                rs.getString("reporter_name"),
                rs.getString("reporter_uuid"),
                rs.getString("reason"),
                rs.getString("report_date"),
                rs.getString("report_time"),
                rs.getLong("timestamp"));
    }
}
