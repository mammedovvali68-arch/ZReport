package com.zreport.database;

import com.zreport.ZReport;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;

/** Bağlantıyı ve tek iş parçacıklı veritabanı executor'ını yönetir; ana thread'i bloke etmez. */
public class DatabaseManager {

    @FunctionalInterface
    public interface Task<T> {
        T run(SQLiteStorage storage) throws Exception;
    }

    private final ZReport plugin;
    private ExecutorService executor;
    private SQLiteStorage storage;

    public DatabaseManager(ZReport plugin) {
        this.plugin = plugin;
    }

    public void connect() throws Exception {
        String type = plugin.getConfig().getString("storage.type", "SQLITE");
        if (!"SQLITE".equalsIgnoreCase(type)) {
            plugin.getLogger().warning("Desteklenmeyen storage.type '" + type + "'. SQLITE kullanılıyor.");
        }
        File folder = plugin.getDataFolder();
        if (!folder.exists() && !folder.mkdirs()) {
            throw new IOException("Eklenti klasörü oluşturulamadı: " + folder);
        }
        File file = new File(folder, plugin.getConfig().getString("storage.file", "reports.db"));
        Class.forName("org.sqlite.JDBC");
        Connection connection = DriverManager.getConnection("jdbc:sqlite:" + file.getAbsolutePath());
        storage = new SQLiteStorage(connection);
        storage.initialize();
        executor = Executors.newSingleThreadExecutor(r -> {
            Thread thread = new Thread(r, "ZReport-Database");
            thread.setDaemon(true);
            return thread;
        });
    }

    public <T> CompletableFuture<T> supply(Task<T> task) {
        CompletableFuture<T> future = new CompletableFuture<>();
        try {
            executor.execute(() -> {
                try {
                    future.complete(task.run(storage));
                } catch (Throwable t) {
                    future.completeExceptionally(t);
                }
            });
        } catch (RejectedExecutionException ex) {
            future.completeExceptionally(ex);
        }
        return future;
    }

    public void close() {
        if (executor != null) {
            executor.shutdown();
            try {
                if (!executor.awaitTermination(10, TimeUnit.SECONDS)) {
                    executor.shutdownNow();
                }
            } catch (InterruptedException e) {
                executor.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }
        if (storage != null) {
            storage.close();
        }
    }
}
