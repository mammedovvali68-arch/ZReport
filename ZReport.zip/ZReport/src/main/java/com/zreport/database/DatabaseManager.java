package com.zreport.database;

import com.zreport.ZReport;
import com.zreport.utils.Log;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;

/**
 * Tek kalıcı SQLite bağlantısını ve tek iş parçacıklı veritabanı executor'ını yönetir.
 * Bütün sorgular bu thread'de sırayla çalışır, böylece ana Minecraft thread'i bloke olmaz
 * ve eşzamanlı yazmalarda veri tutarlı kalır.
 */
public class DatabaseManager {

    @FunctionalInterface
    public interface Task<T> {
        T run(SQLiteStorage storage) throws Exception;
    }

    private final ZReport plugin;
    private final ReportCache cache;
    private File dbFile;
    private volatile ExecutorService executor;
    private volatile SQLiteStorage storage;

    public DatabaseManager(ZReport plugin) {
        this.plugin = plugin;
        this.cache = new ReportCache(
                plugin.getConfig().getBoolean("cache.enabled", true),
                plugin.getConfig().getInt("cache.max-entries", 256),
                plugin.getConfig().getLong("cache.ttl-seconds", 30));
    }

    public ReportCache cache() {
        return cache;
    }

    public void connect() throws Exception {
        String type = plugin.getConfig().getString("storage.type", "SQLITE");
        if (!"SQLITE".equalsIgnoreCase(type)) {
            Log.warn("Unsupported storage.type '" + type + "', using SQLITE.");
        }
        File folder = plugin.getDataFolder();
        if (!folder.exists() && !folder.mkdirs()) {
            throw new IOException("Could not create plugin folder: " + folder);
        }
        dbFile = new File(folder, plugin.getConfig().getString("storage.file", "reports.db"));
        Class.forName("org.sqlite.JDBC");
        storage = openStorage();
        executor = Executors.newSingleThreadExecutor(runnable -> {
            Thread thread = new Thread(runnable, "ZReport-Database");
            thread.setDaemon(true);
            return thread;
        });
        Log.info("Database connection established.");
    }

    private SQLiteStorage openStorage() throws SQLException {
        Connection connection = DriverManager.getConnection("jdbc:sqlite:" + dbFile.getAbsolutePath());
        try {
            if (DatabaseMigration.run(connection, dbFile, plugin.getLogger())) {
                Log.info("Database migration completed.");
            }
        } catch (SQLException | RuntimeException ex) {
            try {
                connection.close();
            } catch (SQLException ignored) {
                // asıl hata önemli
            }
            throw ex;
        }
        return new SQLiteStorage(connection);
    }

    /** Veritabanı thread'inde çağrılır: bağlantı beklenmedik şekilde kapandıysa yeniden açar. */
    private void ensureConnection() throws SQLException {
        SQLiteStorage current = storage;
        if (current == null || !current.isUsable()) {
            Log.warn("Database connection lost, reconnecting...");
            storage = openStorage();
            cache.invalidate();
        }
    }

    public <T> CompletableFuture<T> supply(Task<T> task) {
        CompletableFuture<T> future = new CompletableFuture<>();
        ExecutorService service = executor;
        if (service == null) {
            future.completeExceptionally(new IllegalStateException("Database is not available"));
            return future;
        }
        try {
            service.execute(() -> {
                try {
                    ensureConnection();
                    future.complete(task.run(storage));
                } catch (Throwable throwable) {
                    future.completeExceptionally(throwable);
                }
            });
        } catch (RejectedExecutionException ex) {
            future.completeExceptionally(ex);
        }
        return future;
    }

    /** Bekleyen yazmaların bitmesini bekler, sonra bağlantıyı kapatır. */
    public void close() {
        ExecutorService service = executor;
        executor = null;
        if (service != null) {
            service.shutdown();
            try {
                if (!service.awaitTermination(10, TimeUnit.SECONDS)) {
                    Log.warn("Database tasks did not finish in time, forcing shutdown.");
                    service.shutdownNow();
                }
            } catch (InterruptedException e) {
                service.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }
        SQLiteStorage current = storage;
        storage = null;
        if (current != null) {
            current.close();
            Log.info("Database connection closed.");
        }
        cache.invalidate();
    }
}
