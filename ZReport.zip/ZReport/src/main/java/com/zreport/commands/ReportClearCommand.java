package com.zreport.commands;

import com.zreport.ZReport;
import com.zreport.managers.MessageManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;

import java.util.ArrayList;
import java.util.List;

/** /raportemizle [onayla] - yalnızca zreport.admin. */
public class ReportClearCommand implements TabExecutor {

    private static final String ACTION = "clear";

    private final ZReport plugin;

    public ReportClearCommand(ZReport plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        MessageManager messages = plugin.getMessages();
        if (!sender.hasPermission("zreport.admin")) {
            messages.send(sender, "no-permission");
            return true;
        }
        if (args.length >= 1 && args[0].equalsIgnoreCase("onayla")) {
            if (!plugin.getConfirmations().consume(sender, ACTION)) {
                messages.send(sender, "confirm-expired");
                return true;
            }
            plugin.getReportManager().clearReports(
                    count -> messages.send(sender, "clear-success", "count", String.valueOf(count)),
                    error -> messages.send(sender, "database-error"));
            return true;
        }
        plugin.getConfirmations().request(sender, ACTION);
        messages.send(sender, "clear-confirm", "time", String.valueOf(plugin.getConfirmations().timeoutSeconds()));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> result = new ArrayList<>();
        if (args.length == 1 && sender.hasPermission("zreport.admin") && "onayla".startsWith(args[0].toLowerCase())) {
            result.add("onayla");
        }
        return result;
    }
}
