package com.zreport.commands;

import com.zreport.ZReport;
import com.zreport.gui.ReportDetailsGUI;
import com.zreport.managers.MessageManager;
import com.zreport.models.Report;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.List;

/** /rapordetay <ID> */
public class ReportDetailCommand implements TabExecutor {

    private final ZReport plugin;

    public ReportDetailCommand(ZReport plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        MessageManager messages = plugin.getMessages();
        if (!sender.hasPermission("zreport.list")) {
            messages.send(sender, "no-permission");
            return true;
        }
        if (args.length < 1) {
            messages.send(sender, "usage-detail");
            return true;
        }
        int id;
        try {
            id = Integer.parseInt(args[0].startsWith("#") ? args[0].substring(1) : args[0]);
        } catch (NumberFormatException ex) {
            messages.send(sender, "invalid-id");
            return true;
        }
        if (sender instanceof Player player && plugin.getConfig().getBoolean("settings.use-gui", true)) {
            ReportDetailsGUI.open(plugin, player, id, null);
            return true;
        }
        plugin.getReportManager().getReport(id, optional -> {
            if (optional.isEmpty()) {
                messages.send(sender, "report-not-found");
                return;
            }
            Report report = optional.get();
            String[] placeholders = messages.placeholders(report);
            sender.sendMessage(messages.raw("detail-header", placeholders));
            for (String line : messages.rawList("detail-lines", placeholders)) {
                sender.sendMessage(line);
            }
        }, error -> messages.send(sender, "database-error"));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        return Collections.emptyList();
    }
}
