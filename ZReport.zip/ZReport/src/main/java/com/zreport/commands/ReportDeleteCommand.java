package com.zreport.commands;

import com.zreport.ZReport;
import com.zreport.managers.MessageManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;

import java.util.ArrayList;
import java.util.List;

/** /raporsil <ID> [onayla] - zreport.admin gerektirir. */
public class ReportDeleteCommand implements TabExecutor {

    private final ZReport plugin;

    public ReportDeleteCommand(ZReport plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        MessageManager messages = plugin.getMessages();
        if (!sender.hasPermission("zreport.admin")) {
            messages.send(sender, "no-permission");
            return true;
        }
        if (args.length < 1) {
            messages.send(sender, "usage-delete");
            return true;
        }
        int id;
        try {
            id = Integer.parseInt(args[0].startsWith("#") ? args[0].substring(1) : args[0]);
        } catch (NumberFormatException ex) {
            messages.send(sender, "invalid-id");
            return true;
        }
        String action = "delete:" + id;

        if (args.length >= 2 && args[1].equalsIgnoreCase("onayla")) {
            if (!plugin.getConfirmations().consume(sender, action)) {
                messages.send(sender, "confirm-expired");
                return true;
            }
            plugin.getReportManager().deleteReport(id, deleted -> {
                if (deleted) {
                    messages.send(sender, "delete-success", "id", String.valueOf(id));
                } else {
                    messages.send(sender, "report-not-found");
                }
            }, error -> messages.send(sender, "database-error"));
            return true;
        }

        plugin.getReportManager().getReport(id, optional -> {
            if (optional.isEmpty()) {
                messages.send(sender, "report-not-found");
                return;
            }
            plugin.getConfirmations().request(sender, action);
            messages.send(sender, "delete-confirm", "id", String.valueOf(id),
                    "time", String.valueOf(plugin.getConfirmations().timeoutSeconds()));
        }, error -> messages.send(sender, "database-error"));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> result = new ArrayList<>();
        if (args.length == 2 && sender.hasPermission("zreport.admin") && "onayla".startsWith(args[1].toLowerCase())) {
            result.add("onayla");
        }
        return result;
    }
}
