package com.zreport.commands;

import com.zreport.ZReport;
import com.zreport.gui.ReportGUI;
import com.zreport.managers.MessageManager;
import com.zreport.models.Report;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

/** /raporlist [sayfa] */
public class ReportListCommand implements TabExecutor {

    private final ZReport plugin;

    public ReportListCommand(ZReport plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        MessageManager messages = plugin.getMessages();
        if (!sender.hasPermission("zreport.list")) {
            messages.send(sender, "no-permission");
            return true;
        }
        int page = 1;
        if (args.length >= 1) {
            try {
                page = Integer.parseInt(args[0]);
            } catch (NumberFormatException ex) {
                page = 0;
            }
            if (page < 1) {
                messages.send(sender, "invalid-page");
                return true;
            }
        }

        if (sender instanceof Player player && plugin.getConfig().getBoolean("settings.use-gui", true)) {
            ReportGUI.open(plugin, player, page);
            return true;
        }

        int perPage = Math.max(1, plugin.getConfig().getInt("settings.reports-per-page", 7));
        plugin.getReportManager().getPage(page, perPage, result -> {
            if (result.totalCount() == 0) {
                messages.send(sender, "report-list-empty");
                return;
            }
            String pageValue = String.valueOf(result.page());
            String pagesValue = String.valueOf(result.totalPages());
            sender.sendMessage(messages.raw("list-header", "page", pageValue, "pages", pagesValue));
            for (Report report : result.reports()) {
                for (String line : messages.rawList("list-entry", messages.placeholders(report))) {
                    sender.sendMessage(line);
                }
            }
            sender.sendMessage(messages.raw("list-footer", "page", pageValue, "pages", pagesValue));
        }, error -> messages.send(sender, "database-error"));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> result = new ArrayList<>();
        if (args.length == 1 && sender.hasPermission("zreport.list")) {
            result.add("1");
        }
        return result;
    }
}
