package com.zreport.commands;

import com.zreport.ZReport;
import com.zreport.gui.ReportDashboardGUI;
import com.zreport.gui.ReportListGUI;
import com.zreport.managers.MessageManager;
import com.zreport.models.Report;
import com.zreport.models.ReportStatus;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Oyuncu: /raporlist -> yönetim paneli, /raporlist <active|reviewed|punished> [sayfa] -> doğrudan kategori.
 * Konsol (veya use-gui: false): /raporlist [sayfa] -> sohbet listesi.
 */
public class ReportListCommand implements TabExecutor {

    private static final List<String> CATEGORIES = List.of("active", "reviewed", "punished");

    private final ZReport plugin;

    public ReportListCommand(ZReport plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        MessageManager messages = plugin.getMessages();
        if (!sender.hasPermission("zreport.list")) {
            messages.send(sender, "no-permission");
            return true;
        }
        boolean gui = sender instanceof Player && plugin.getConfig().getBoolean("settings.use-gui", true);
        if (gui) {
            Player player = (Player) sender;
            if (args.length == 0) {
                ReportDashboardGUI.open(plugin, player);
                return true;
            }
            ReportStatus status = parseStatus(args[0]);
            if (status == null) {
                messages.send(sender, "usage-list");
                return true;
            }
            int page = args.length >= 2 ? parsePage(args[1]) : 1;
            if (page < 1) {
                messages.send(sender, "invalid-page");
                return true;
            }
            ReportListGUI.open(plugin, player, status, page);
            return true;
        }

        int page = args.length >= 1 ? parsePage(args[0]) : 1;
        if (page < 1) {
            messages.send(sender, "invalid-page");
            return true;
        }
        int perPage = Math.max(1, plugin.getConfig().getInt("settings.reports-per-page", 7));
        plugin.getReportManager().getPage(page, perPage, result -> {
            if (result.totalCount() == 0) {
                messages.send(sender, "report-list-empty");
                return;
            }
            String pageValue = String.valueOf(result.page());
            String pagesValue = String.valueOf(result.totalPages());
            sender.sendMessage(messages.raw("list-header", "page", pageValue, "pages", pagesValue));
            for (Report report : result.reports()) {
                int total = result.targetTotals().getOrDefault(report.id(), 0);
                for (String line : messages.rawList("list-entry", messages.placeholders(report, total))) {
                    sender.sendMessage(line);
                }
            }
            sender.sendMessage(messages.raw("list-footer", "page", pageValue, "pages", pagesValue));
        }, error -> messages.send(sender, "database-error"));
        return true;
    }

    private static int parsePage(String text) {
        try {
            return Integer.parseInt(text);
        } catch (NumberFormatException ex) {
            return 0;
        }
    }

    private static ReportStatus parseStatus(String text) {
        String value = text.toLowerCase(Locale.ROOT);
        return switch (value) {
            case "active", "aktif" -> ReportStatus.ACTIVE;
            case "reviewed", "incelenmis", "incelenmiş" -> ReportStatus.REVIEWED;
            case "punished", "cezali", "cezalı" -> ReportStatus.PUNISHED;
            default -> null;
        };
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> result = new ArrayList<>();
        if (args.length == 1 && sender.hasPermission("zreport.list")) {
            for (String category : CATEGORIES) {
                if (category.startsWith(args[0].toLowerCase(Locale.ROOT))) {
                    result.add(category);
                }
            }
        }
        return result;
    }
}
