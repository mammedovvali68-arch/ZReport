package com.zreport.commands;

import com.zreport.ZReport;
import com.zreport.managers.MessageManager;
import com.zreport.models.Report;
import com.zreport.utils.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.regex.Pattern;

/** /rapor <oyuncu> [sebep] */
public class ReportCommand implements TabExecutor {

    private static final Pattern NAME_PATTERN = Pattern.compile("^\\.?[A-Za-z0-9_]{3,16}$");

    private final ZReport plugin;

    public ReportCommand(ZReport plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        MessageManager messages = plugin.getMessages();

        if (!(sender instanceof Player player)) {
            messages.send(sender, "player-only");
            return true;
        }
        if (!player.hasPermission("zreport.report")) {
            messages.send(player, "no-permission");
            return true;
        }
        if (args.length < 1) {
            messages.send(player, "usage-report");
            return true;
        }

        // Hedef oyuncu
        String input = args[0];
        if (!NAME_PATTERN.matcher(input).matches()) {
            messages.send(player, "invalid-player", "player", TextUtil.sanitize(input));
            return true;
        }
        String targetName;
        String targetUuid = null;
        Player online = Bukkit.getPlayerExact(input);
        if (online != null) {
            targetName = online.getName();
            targetUuid = online.getUniqueId().toString();
        } else if (!plugin.getConfig().getBoolean("settings.allow-offline-reports", true)) {
            messages.send(player, "player-not-found", "player", input);
            return true;
        } else {
            OfflinePlayer offline = Bukkit.getOfflinePlayerIfCached(input);
            if (offline != null) {
                targetUuid = offline.getUniqueId().toString();
                targetName = offline.getName() != null ? offline.getName() : input;
            } else {
                targetName = input;
            }
        }

        // Kendini raporlama
        if (targetName.equalsIgnoreCase(player.getName())
                || (targetUuid != null && targetUuid.equals(player.getUniqueId().toString()))) {
            messages.send(player, "cannot-report-yourself");
            return true;
        }

        // Sebep
        String reason = args.length > 1
                ? TextUtil.sanitize(String.join(" ", Arrays.copyOfRange(args, 1, args.length)))
                : "";
        if (reason.isEmpty()) {
            reason = plugin.getConfig().getString("messages.default-reason", "Sebep belirtilmedi");
        } else {
            int min = Math.max(1, plugin.getConfig().getInt("settings.min-reason-length", 3));
            int max = Math.max(min, plugin.getConfig().getInt("settings.max-reason-length", 150));
            if (reason.length() < min || !TextUtil.hasLetterOrDigit(reason)) {
                messages.send(player, "invalid-reason", "min", String.valueOf(min));
                return true;
            }
            if (reason.length() > max) {
                messages.send(player, "reason-too-long", "max", String.valueOf(max));
                return true;
            }
        }

        // Cooldown (admin muaf)
        UUID reporterId = player.getUniqueId();
        if (!player.hasPermission("zreport.admin")) {
            long remaining = plugin.getCooldowns().remainingSeconds(reporterId);
            if (remaining > 0) {
                messages.send(player, "cooldown", "time", String.valueOf(remaining));
                return true;
            }
        }
        plugin.getCooldowns().mark(reporterId);

        Report draft = Report.create(targetName, targetUuid, player.getName(), reporterId.toString(), reason);
        plugin.getReportManager().createReport(draft, saved -> {
            messages.send(player, "report-success", "player", saved.reportedName());
            notifyStaff(player, saved);
        }, error -> {
            plugin.getCooldowns().clear(reporterId);
            messages.send(player, "database-error");
        });
        return true;
    }

    private void notifyStaff(Player reporter, Report report) {
        if (!plugin.getConfig().getBoolean("settings.notify-staff", true)) {
            return;
        }
        MessageManager messages = plugin.getMessages();
        for (Player staff : Bukkit.getOnlinePlayers()) {
            if (!staff.equals(reporter) && staff.hasPermission("zreport.list")) {
                messages.send(staff, "staff-notification", messages.placeholders(report));
            }
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> result = new ArrayList<>();
        if (!(sender instanceof Player player) || !player.hasPermission("zreport.report")) {
            return result;
        }
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            for (Player online : Bukkit.getOnlinePlayers()) {
                if (!online.equals(player) && online.getName().toLowerCase(Locale.ROOT).startsWith(prefix)) {
                    result.add(online.getName());
                }
            }
        } else if (args.length == 2) {
            String prefix = args[1].toLowerCase(Locale.ROOT);
            for (String suggestion : plugin.getConfig().getStringList("settings.reason-suggestions")) {
                if (suggestion.toLowerCase(Locale.ROOT).startsWith(prefix)) {
                    result.add(suggestion);
                }
            }
        }
        return result;
    }
}
