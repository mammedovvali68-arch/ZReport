package com.zreport.commands;

import com.zreport.ZReport;
import com.zreport.gui.PlayerSelectionGUI;
import com.zreport.managers.MessageManager;
import com.zreport.managers.ReportManager;
import com.zreport.models.Report;
import com.zreport.utils.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.regex.Pattern;

/**
 * /rapor            -> oyuncu seçim GUI'si (V2)
 * /rapor <oyuncu> [sebep] -> V1 hızlı komutu (settings.allow-legacy-report-command: false ile kapatılabilir)
 */
public class ReportCommand implements TabExecutor {

    private static final Pattern NAME_PATTERN = Pattern.compile("^\\.?[A-Za-z0-9_]{3,16}$");

    private final ZReport plugin;

    public ReportCommand(ZReport plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        MessageManager messages = plugin.getMessages();
        if (!(sender instanceof Player player)) {
            messages.send(sender, "player-only");
            return true;
        }
        if (!player.hasPermission("zreport.report")) {
            messages.send(player, "no-permission");
            return true;
        }
        boolean legacy = plugin.getConfig().getBoolean("settings.allow-legacy-report-command", true);
        if (args.length == 0 || !legacy) {
            PlayerSelectionGUI.open(plugin, player, 1);
            return true;
        }
        quickReport(player, args);
        return true;
    }

    private void quickReport(Player player, String[] args) {
        MessageManager messages = plugin.getMessages();
        ReportManager reports = plugin.getReportManager();

        String input = args[0];
        if (!NAME_PATTERN.matcher(input).matches()) {
            messages.send(player, "invalid-player", "player", TextUtil.sanitize(input));
            return;
        }
        String targetName;
        String targetUuid = null;
        Player online = Bukkit.getPlayerExact(input);
        if (online != null) {
            targetName = online.getName();
            targetUuid = online.getUniqueId().toString();
        } else if (!plugin.getConfig().getBoolean("settings.allow-offline-reports", true)) {
            messages.send(player, "player-not-found", "player", input);
            return;
        } else {
            OfflinePlayer offline = Bukkit.getOfflinePlayerIfCached(input);
            if (offline != null) {
                targetUuid = offline.getUniqueId().toString();
                targetName = offline.getName() != null ? offline.getName() : input;
            } else {
                targetName = input;
            }
        }
        if (targetName.equalsIgnoreCase(player.getName())
                || (targetUuid != null && targetUuid.equals(player.getUniqueId().toString()))) {
            messages.send(player, "cannot-report-yourself");
            return;
        }

        String reason = args.length > 1
                ? TextUtil.sanitize(String.join(" ", Arrays.copyOfRange(args, 1, args.length))) : "";
        if (reason.isEmpty()) {
            reason = reports.defaultReason();
        } else {
            String error = reports.reasonError(reason);
            if (error != null) {
                player.sendMessage(error);
                return;
            }
        }

        UUID reporterId = player.getUniqueId();
        if (!player.hasPermission("zreport.admin")) {
            long remaining = plugin.getCooldowns().remainingSeconds(reporterId);
            if (remaining > 0) {
                messages.send(player, "cooldown", "time", String.valueOf(remaining));
                return;
            }
        }
        if (!plugin.getGuiManager().tryLock(player)) {
            return;
        }
        plugin.getCooldowns().mark(reporterId);

        Report draft = Report.create(targetName, targetUuid, player.getName(), reporterId.toString(), reason, false);
        boolean checkDuplicate = plugin.getConfig().getBoolean("settings.block-duplicate-active", true);
        reports.createReport(draft, checkDuplicate, saved -> {
            plugin.getGuiManager().unlock(player);
            if (saved.isEmpty()) {
                plugin.getCooldowns().clear(reporterId);
                messages.send(player, "already-reported", "player", draft.reportedName());
                return;
            }
            messages.send(player, "report-success", "player", saved.get().reportedName());
            reports.notifyStaff(saved.get(), player);
        }, error -> {
            plugin.getGuiManager().unlock(player);
            plugin.getCooldowns().clear(reporterId);
            messages.send(player, "database-error");
        });
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> result = new ArrayList<>();
        if (!(sender instanceof Player player) || !player.hasPermission("zreport.report")
                || !plugin.getConfig().getBoolean("settings.allow-legacy-report-command", true)) {
            return result;
        }
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            for (Player online : Bukkit.getOnlinePlayers()) {
                if (!online.equals(player) && online.getName().toLowerCase(Locale.ROOT).startsWith(prefix)) {
                    result.add(online.getName());
                }
            }
        } else if (args.length == 2) {
            String prefix = args[1].toLowerCase(Locale.ROOT);
            for (String suggestion : plugin.getConfig().getStringList("settings.reason-suggestions")) {
                if (suggestion.toLowerCase(Locale.ROOT).startsWith(prefix)) {
                    result.add(suggestion);
                }
            }
        }
        return result;
    }
}
