package com.zreport.punishment;

import com.zreport.models.Punishment;

/** Cezayı gerçekten uygulayan sağlayıcı. Ana thread'de çağrılır. */
public interface PunishmentProvider {

    /** Başarılıysa null, değilse mesaj anahtarı (config messages.*) döner. */
    String apply(Punishment punishment);
}
