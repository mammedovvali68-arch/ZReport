package com.zreport.punishment;

import com.zreport.ZReport;
import com.zreport.models.Punishment;
import com.zreport.models.PunishmentType;
import com.zreport.utils.DateUtils;
import com.zreport.utils.Log;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.regex.Pattern;

/**
 * Opsiyonel entegrasyon: LiteBans, AdvancedBan vb. için config'deki konsol komutlarını çalıştırır.
 * Komutu tanımlı olmayan WARNING/KICK/OTHER cezaları Paper sağlayıcısına devredilir.
 */
public class CommandPunishmentProvider implements PunishmentProvider {

    private static final Pattern SAFE_NAME = Pattern.compile("^[A-Za-z0-9_.]{1,17}$");

    private final ZReport plugin;
    private final PaperPunishmentProvider fallback;

    public CommandPunishmentProvider(ZReport plugin, PaperPunishmentProvider fallback) {
        this.plugin = plugin;
        this.fallback = fallback;
    }

    @Override
    public String apply(Punishment punishment) {
        PunishmentType type = punishment.type();
        String template = plugin.getConfig().getString("punishment.commands." + type.name(), "");
        if (template == null || template.isBlank()) {
            boolean paperHandled = type == PunishmentType.WARNING || type == PunishmentType.KICK
                    || type == PunishmentType.OTHER;
            return paperHandled ? fallback.apply(punishment) : "punish-failed";
        }
        Player online = PaperPunishmentProvider.findOnline(punishment);
        String name = PaperPunishmentProvider.resolveName(punishment, online);
        if (!SAFE_NAME.matcher(name).matches()) {
            return "punish-failed";
        }
        String command = template
                .replace("%player%", name)
                .replace("%reason%", punishment.reason())
                .replace("%staff%", punishment.staffName())
                .replace("%duration%", DateUtils.compact(Math.max(1, punishment.durationSeconds())));
        if (command.startsWith("/")) {
            command = command.substring(1);
        }
        try {
            return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command) ? null : "punish-failed";
        } catch (Throwable throwable) {
            Log.error("Punishment command failed", throwable);
            return "punish-failed";
        }
    }
}
