package com.zreport.punishment;

import com.zreport.ZReport;
import com.zreport.models.Punishment;
import com.zreport.models.PunishmentType;
import com.zreport.models.Report;
import com.zreport.models.ReportStatus;
import com.zreport.utils.Log;
import com.zreport.utils.Permissions;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Önce cezayı gerçekten uygular, ancak başarılı olursa raporu PUNISHED yapar.
 * Ceza uygulanamadıysa rapor cezalandırılmış gibi gösterilmez.
 */
public class PunishmentManager {

    public record DurationOption(String key, String label, long seconds) {
    }

    private final ZReport plugin;
    private final PunishmentProvider provider;

    public PunishmentManager(ZReport plugin) {
        this.plugin = plugin;
        PaperPunishmentProvider paper = new PaperPunishmentProvider(plugin);
        String mode = plugin.getConfig().getString("punishment.provider", "PAPER");
        this.provider = "COMMAND".equalsIgnoreCase(mode) ? new CommandPunishmentProvider(plugin, paper) : paper;
    }

    public List<PunishmentType> enabledTypes() {
        List<PunishmentType> list = new ArrayList<>();
        for (PunishmentType type : PunishmentType.values()) {
            if (plugin.getConfig().getBoolean("punishment.types." + type.name() + ".enabled", true)) {
                list.add(type);
            }
        }
        return list;
    }

    public List<DurationOption> durations() {
        List<DurationOption> list = new ArrayList<>();
        ConfigurationSection section = plugin.getConfig().getConfigurationSection("punishment.durations");
        if (section == null) {
            return list;
        }
        for (String key : section.getKeys(false)) {
            long seconds = section.getLong(key + ".seconds", 0);
            if (seconds > 0 && list.size() < 7) {
                list.add(new DurationOption(key, plugin.getMessages().apply(section.getString(key + ".label", key)), seconds));
            }
        }
        return list;
    }

    public String defaultReason() {
        return plugin.getConfig().getString("punishment.default-reason", "Kural ihlali");
    }

    /**
     * done: başarılıysa null, değilse mesaj anahtarı. Ana thread'de çağrılmalı.
     * Ceza uygulanmadan önce rapor veritabanından yeniden okunur: başka bir yetkili raporu zaten
     * cezalandırdıysa veya silindiyse ceza uygulanmaz; yetki de bu noktada tekrar doğrulanır.
     */
    public void apply(Player staff, Report staleReport, PunishmentType type, String reason, long durationSeconds,
                      Consumer<String> done) {
        plugin.getReportManager().getReport(staleReport.id(), current -> {
            if (!staff.isOnline()) {
                return;
            }
            if (!staff.hasPermission(Permissions.PUNISH)) {
                done.accept("no-permission");
            } else if (current.isEmpty()) {
                done.accept("report-not-found");
            } else if (current.get().status() == ReportStatus.PUNISHED) {
                done.accept("punish-already");
            } else {
                applyNow(staff, current.get(), type, reason, durationSeconds, done);
            }
        }, failure -> done.accept("database-error"));
    }

    private void applyNow(Player staff, Report report, PunishmentType type, String reason, long durationSeconds,
                          Consumer<String> done) {
        Punishment punishment = new Punishment(type, reason, durationSeconds, report.reportedUuid(),
                report.reportedName(), staff.getName());
        String error;
        try {
            error = provider.apply(punishment);
        } catch (Throwable throwable) {
            Log.error("Punishment provider failed", throwable);
            error = "punish-failed";
        }
        if (error != null) {
            done.accept(error);
            return;
        }
        plugin.getReportManager().markPunished(report.id(), type, reason, durationSeconds, staff,
                recorded -> done.accept(recorded ? null : "punish-already"),
                failure -> done.accept("punish-record-failed"));
        Log.info("Punishment " + type + " applied to " + report.reportedName() + " (report #" + report.id() + ").");
    }
}
