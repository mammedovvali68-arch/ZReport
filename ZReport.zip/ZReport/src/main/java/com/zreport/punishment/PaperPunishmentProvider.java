package com.zreport.punishment;

import com.zreport.ZReport;
import com.zreport.managers.MessageManager;
import com.zreport.models.Punishment;
import com.zreport.models.PunishmentType;
import com.zreport.utils.Log;
import com.zreport.utils.DateUtils;
import org.bukkit.BanList;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.Date;
import java.util.UUID;

/** Paper/Bukkit API ile ceza uygular: uyarı mesajı, kick ve ban listesi. */
public class PaperPunishmentProvider implements PunishmentProvider {

    private final ZReport plugin;

    public PaperPunishmentProvider(ZReport plugin) {
        this.plugin = plugin;
    }

    @Override
    @SuppressWarnings({"deprecation", "rawtypes", "unchecked"})
    public String apply(Punishment punishment) {
        MessageManager messages = plugin.getMessages();
        Player online = findOnline(punishment);
        String[] ph = {
                "reason", punishment.reason(),
                "staff", punishment.staffName(),
                "duration", DateUtils.human(punishment.durationSeconds()),
                "player", punishment.targetName()};
        try {
            PunishmentType type = punishment.type();
            switch (type) {
                case WARNING:
                    if (online == null) {
                        return "punish-target-offline";
                    }
                    online.sendMessage(messages.path("punishment.screens.warning", ph));
                    return null;
                case KICK:
                    if (online == null) {
                        return "punish-target-offline";
                    }
                    online.kickPlayer(messages.path("punishment.screens.kick", ph));
                    return null;
                case TEMPBAN:
                case PERMBAN:
                    Date expires = type == PunishmentType.TEMPBAN
                            ? new Date(System.currentTimeMillis() + punishment.durationSeconds() * 1000L) : null;
                    BanList list = Bukkit.getBanList(BanList.Type.NAME);
                    list.addBan(resolveName(punishment, online), punishment.reason(), expires, punishment.staffName());
                    if (online != null) {
                        String screen = type == PunishmentType.TEMPBAN ? "punishment.screens.tempban"
                                : "punishment.screens.permban";
                        online.kickPlayer(messages.path(screen, ph));
                    }
                    return null;
                default:
                    // OTHER: otomatik bir işlem yok, yetkili cezayı elle uyguladı.
                    return null;
            }
        } catch (Throwable throwable) {
            Log.error("Punishment could not be applied", throwable);
            return "punish-failed";
        }
    }

    static Player findOnline(Punishment punishment) {
        if (punishment.targetUuid() != null) {
            try {
                return Bukkit.getPlayer(UUID.fromString(punishment.targetUuid()));
            } catch (IllegalArgumentException ignored) {
                // geçersiz UUID: isme düş
            }
        }
        return Bukkit.getPlayerExact(punishment.targetName());
    }

    /** Oyuncu ismi değişmiş olabilir; UUID biliniyorsa güncel isim kullanılır. */
    static String resolveName(Punishment punishment, Player online) {
        if (online != null) {
            return online.getName();
        }
        if (punishment.targetUuid() != null) {
            try {
                String current = Bukkit.getOfflinePlayer(UUID.fromString(punishment.targetUuid())).getName();
                if (current != null) {
                    return current;
                }
            } catch (IllegalArgumentException ignored) {
                // geçersiz UUID: kayıtlı isim
            }
        }
        return punishment.targetName();
    }
}
