package com.zreport;

import com.zreport.commands.ReportClearCommand;
import com.zreport.commands.ReportCommand;
import com.zreport.commands.ReportDeleteCommand;
import com.zreport.commands.ReportDetailCommand;
import com.zreport.commands.ReportListCommand;
import com.zreport.database.DatabaseManager;
import com.zreport.gui.GUIManager;
import com.zreport.listeners.GUIListener;
import com.zreport.listeners.PlayerListener;
import com.zreport.managers.ChatInputManager;
import com.zreport.managers.ConfirmationManager;
import com.zreport.managers.CooldownManager;
import com.zreport.managers.MessageManager;
import com.zreport.managers.ReportHistoryManager;
import com.zreport.managers.ReportManager;
import com.zreport.punishment.PunishmentManager;
import com.zreport.utils.DateUtils;
import com.zreport.utils.GUIUtils;
import com.zreport.utils.Log;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.Configuration;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

public final class ZReport extends JavaPlugin {

    private MessageManager messageManager;
    private DatabaseManager databaseManager;
    private ReportManager reportManager;
    private CooldownManager cooldownManager;
    private ConfirmationManager confirmationManager;
    private ChatInputManager chatInputManager;
    private ReportHistoryManager historyManager;
    private PunishmentManager punishmentManager;
    private GUIManager guiManager;

    @Override
    @SuppressWarnings("deprecation")
    public void onEnable() {
        long start = System.currentTimeMillis();
        saveDefaultConfig();
        mergeNewDefaults();
        Log.init(getLogger(), getConfig().getBoolean("settings.debug", false));
        DateUtils.configure(getConfig());
        try {
            messageManager = new MessageManager(this);
            databaseManager = new DatabaseManager(this);
            databaseManager.connect();
            reportManager = new ReportManager(this, databaseManager);
            cooldownManager = new CooldownManager(this);
            confirmationManager = new ConfirmationManager(this);
            chatInputManager = new ChatInputManager(this);
            historyManager = new ReportHistoryManager(this);
            punishmentManager = new PunishmentManager(this);
            guiManager = new GUIManager(this);
            Log.info("GUI Manager initialized.");

            register("rapor", new ReportCommand(this));
            register("raporlist", new ReportListCommand(this));
            register("raporsil", new ReportDeleteCommand(this));
            register("rapordetay", new ReportDetailCommand(this));
            register("raportemizle", new ReportClearCommand(this));

            getServer().getPluginManager().registerEvents(new GUIListener(this), this);
            getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
            Log.info("Plugin successfully enabled (v" + getDescription().getVersion() + ", "
                    + (System.currentTimeMillis() - start) + " ms).");
        } catch (Exception ex) {
            Log.error("Plugin could not start, disabling", ex);
            getServer().getPluginManager().disablePlugin(this);
        }
    }

    @Override
    public void onDisable() {
        // Sıra önemli: önce menüler ve bekleyen girişler, sonra görevler, en son veritabanı.
        if (guiManager != null) {
            guiManager.closeAll();
        }
        if (chatInputManager != null) {
            chatInputManager.shutdown();
        }
        getServer().getScheduler().cancelTasks(this);
        if (databaseManager != null) {
            databaseManager.close();
        }
        GUIUtils.clearCache();
        Log.info("Plugin successfully disabled.");
    }

    /** V1/V2'den yükseltmede eksik ayar anahtarlarını mevcut config.yml'ye ekler (değerler korunur). */
    private void mergeNewDefaults() {
        FileConfiguration config = getConfig();
        Configuration defaults = config.getDefaults();
        if (defaults == null) {
            return;
        }
        for (String key : defaults.getKeys(true)) {
            if (!config.isSet(key)) {
                config.options().copyDefaults(true);
                saveConfig();
                getLogger().info("config.yml was updated with new default settings.");
                return;
            }
        }
    }

    private void register(String name, TabExecutor executor) {
        PluginCommand command = getCommand(name);
        if (command == null) {
            throw new IllegalStateException("Command '" + name + "' is missing from plugin.yml");
        }
        command.setExecutor(executor);
        command.setTabCompleter(executor);
    }

    public MessageManager getMessages() {
        return messageManager;
    }

    public ReportManager getReportManager() {
        return reportManager;
    }

    public CooldownManager getCooldowns() {
        return cooldownManager;
    }

    public ConfirmationManager getConfirmations() {
        return confirmationManager;
    }

    public ChatInputManager getChatInput() {
        return chatInputManager;
    }

    public ReportHistoryManager getHistoryManager() {
        return historyManager;
    }

    public PunishmentManager getPunishmentManager() {
        return punishmentManager;
    }

    public GUIManager getGuiManager() {
        return guiManager;
    }
}
