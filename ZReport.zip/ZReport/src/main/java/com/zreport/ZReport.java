package com.zreport;

import com.zreport.commands.ReportClearCommand;
import com.zreport.commands.ReportCommand;
import com.zreport.commands.ReportDeleteCommand;
import com.zreport.commands.ReportDetailCommand;
import com.zreport.commands.ReportListCommand;
import com.zreport.database.DatabaseManager;
import com.zreport.gui.GUIManager;
import com.zreport.listeners.GUIListener;
import com.zreport.listeners.PlayerListener;
import com.zreport.managers.ChatInputManager;
import com.zreport.managers.ConfirmationManager;
import com.zreport.managers.CooldownManager;
import com.zreport.managers.MessageManager;
import com.zreport.managers.ReportHistoryManager;
import com.zreport.managers.ReportManager;
import com.zreport.punishment.PunishmentManager;
import com.zreport.utils.DateUtils;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabExecutor;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.logging.Level;

public final class ZReport extends JavaPlugin {

    private MessageManager messageManager;
    private DatabaseManager databaseManager;
    private ReportManager reportManager;
    private CooldownManager cooldownManager;
    private ConfirmationManager confirmationManager;
    private ChatInputManager chatInputManager;
    private ReportHistoryManager historyManager;
    private PunishmentManager punishmentManager;
    private GUIManager guiManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        // V1'den yükseltmede eksik V2 anahtarları mevcut config.yml'ye eklenir (değerler korunur).
        getConfig().options().copyDefaults(true);
        saveConfig();
        DateUtils.configure(getConfig());
        messageManager = new MessageManager(this);
        databaseManager = new DatabaseManager(this);
        try {
            databaseManager.connect();
        } catch (Exception ex) {
            getLogger().log(Level.SEVERE, "Veritabanına bağlanılamadı, eklenti devre dışı bırakılıyor.", ex);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        reportManager = new ReportManager(this, databaseManager);
        cooldownManager = new CooldownManager(this);
        confirmationManager = new ConfirmationManager(this);
        chatInputManager = new ChatInputManager(this);
        historyManager = new ReportHistoryManager(this);
        punishmentManager = new PunishmentManager(this);
        guiManager = new GUIManager(this);

        register("rapor", new ReportCommand(this));
        register("raporlist", new ReportListCommand(this));
        register("raporsil", new ReportDeleteCommand(this));
        register("rapordetay", new ReportDetailCommand(this));
        register("raportemizle", new ReportClearCommand(this));

        getServer().getPluginManager().registerEvents(new GUIListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
        getLogger().info("ZReport " + getDescription().getVersion() + " etkinleştirildi.");
    }

    @Override
    public void onDisable() {
        if (databaseManager != null) {
            databaseManager.close();
        }
    }

    private void register(String name, TabExecutor executor) {
        PluginCommand command = getCommand(name);
        if (command == null) {
            throw new IllegalStateException("plugin.yml içinde '" + name + "' komutu bulunamadı.");
        }
        command.setExecutor(executor);
        command.setTabCompleter(executor);
    }

    public MessageManager getMessages() {
        return messageManager;
    }

    public ReportManager getReportManager() {
        return reportManager;
    }

    public CooldownManager getCooldowns() {
        return cooldownManager;
    }

    public ConfirmationManager getConfirmations() {
        return confirmationManager;
    }

    public ChatInputManager getChatInput() {
        return chatInputManager;
    }

    public ReportHistoryManager getHistoryManager() {
        return historyManager;
    }

    public PunishmentManager getPunishmentManager() {
        return punishmentManager;
    }

    public GUIManager getGuiManager() {
        return guiManager;
    }
}
