package com.zreport.listeners;

import com.zreport.ZReport;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/** Sohbet tabanlı girişleri yakalar ve oyuncu çıkınca durumu temizler. */
public class PlayerListener implements Listener {

    private final ZReport plugin;

    public PlayerListener(ZReport plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getChatInput().isWaiting(player.getUniqueId())) {
            return;
        }
        event.setCancelled(true);
        String message = event.getMessage();
        // Bukkit API'si ana thread'de kullanılmalı.
        Bukkit.getScheduler().runTask(plugin, () -> plugin.getChatInput().handle(player, message));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        plugin.getChatInput().clear(player.getUniqueId());
        plugin.getGuiManager().cleanup(player.getUniqueId());
        plugin.getConfirmations().clear(player);
    }
}
