package com.zreport.listeners;

import com.zreport.ZReport;
import com.zreport.gui.ReportDetailGUI;
import com.zreport.gui.ReportGUI;
import com.zreport.managers.MessageManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.InventoryHolder;

/** GUI tıklamalarını yönetir ve menülerde istenmeyen envanter işlemlerini engeller. */
public class GUIListener implements Listener {

    private final ZReport plugin;

    public GUIListener(ZReport plugin) {
        this.plugin = plugin;
    }

    private boolean isReportMenu(InventoryHolder holder) {
        return holder instanceof ReportGUI || holder instanceof ReportDetailGUI;
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (isReportMenu(event.getInventory().getHolder())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        InventoryHolder holder = event.getInventory().getHolder();
        if (!isReportMenu(holder)) {
            return;
        }
        // Shift-click, sayı tuşu, çift tık vb. dahil her şeyi iptal et.
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        if (event.getClickedInventory() == null || event.getClickedInventory() != event.getInventory()) {
            return;
        }
        if (!event.isLeftClick() && !event.isRightClick()) {
            return;
        }
        MessageManager messages = plugin.getMessages();
        if (!player.hasPermission("zreport.list")) {
            player.closeInventory();
            messages.send(player, "no-permission");
            return;
        }

        int slot = event.getSlot();
        if (holder instanceof ReportGUI gui) {
            handleList(player, gui, slot);
        } else if (holder instanceof ReportDetailGUI detail) {
            handleDetail(player, detail, slot);
        }
    }

    private void handleList(Player player, ReportGUI gui, int slot) {
        if (slot == ReportGUI.PREV_SLOT && gui.page() > 1) {
            ReportGUI.open(plugin, player, gui.page() - 1);
        } else if (slot == ReportGUI.NEXT_SLOT && gui.page() < gui.totalPages()) {
            ReportGUI.open(plugin, player, gui.page() + 1);
        } else {
            Integer id = gui.reportIdAt(slot);
            if (id != null) {
                ReportDetailGUI.open(plugin, player, id, gui.page());
            }
        }
    }

    private void handleDetail(Player player, ReportDetailGUI detail, int slot) {
        MessageManager messages = plugin.getMessages();
        if (slot == ReportDetailGUI.BACK_SLOT) {
            ReportGUI.open(plugin, player, detail.returnPage());
            return;
        }
        if (slot != ReportDetailGUI.DELETE_SLOT) {
            return;
        }
        if (!player.hasPermission("zreport.admin")) {
            messages.send(player, "no-permission");
            return;
        }
        int id = detail.report().id();
        String action = "delete:" + id;
        if (plugin.getConfirmations().consume(player, action)) {
            plugin.getReportManager().deleteReport(id, deleted -> {
                if (deleted) {
                    messages.send(player, "delete-success", "id", String.valueOf(id));
                } else {
                    messages.send(player, "report-not-found");
                }
                if (player.isOnline()) {
                    ReportGUI.open(plugin, player, detail.returnPage());
                }
            }, error -> messages.send(player, "database-error"));
        } else {
            plugin.getConfirmations().request(player, action);
            messages.send(player, "gui-delete-confirm", "time", String.valueOf(plugin.getConfirmations().timeoutSeconds()));
        }
    }
}
