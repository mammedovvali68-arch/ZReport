package com.zreport.listeners;

import com.zreport.ZReport;
import com.zreport.gui.BaseGUI;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

/** GUI tıklamalarını yönlendirir; menülerde item alma/taşıma/bırakma gibi her işlemi engeller. */
public class GUIListener implements Listener {

    private final ZReport plugin;

    public GUIListener(ZReport plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getInventory().getHolder() instanceof BaseGUI) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof BaseGUI gui)) {
            return;
        }
        // Shift-click, sayı tuşu, çift tık vb. dahil her şeyi iptal et.
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        if (event.getClickedInventory() == null || event.getClickedInventory() != event.getInventory()) {
            return;
        }
        ClickType click = event.getClick();
        if (click != ClickType.LEFT && click != ClickType.RIGHT
                && click != ClickType.SHIFT_LEFT && click != ClickType.SHIFT_RIGHT) {
            return;
        }
        if (!player.hasPermission(gui.permission())) {
            player.closeInventory();
            plugin.getMessages().send(player, "no-permission");
            return;
        }
        if (!plugin.getGuiManager().allowClick(player)) {
            return;
        }
        gui.onClick(event.getSlot(), click);
    }
}
