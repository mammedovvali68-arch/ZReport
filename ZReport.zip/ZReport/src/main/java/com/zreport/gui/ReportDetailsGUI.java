package com.zreport.gui;

import com.zreport.ZReport;
import com.zreport.managers.ConfirmationManager;
import com.zreport.managers.ReportHistoryManager.PlayerHistory;
import com.zreport.models.Report;
import com.zreport.models.ReportStatus;
import com.zreport.utils.GUIUtils;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.Locale;

/** Tek raporun ayrıntıları, oyuncu geçmişi özeti ve yetkili işlemleri. */
public class ReportDetailsGUI extends BaseGUI {

    private static final int HEAD = 4;
    private static final int REPORTER = 10;
    private static final int REASON = 12;
    private static final int EVIDENCE = 14;
    private static final int DATE = 16;
    private static final int STATUS = 20;
    private static final int HISTORY = 22;
    private static final int REVIEW = 37;
    private static final int PUNISH = 39;
    private static final int DELETE = 43;
    private static final int BACK = 45;
    private static final int CLOSE = 53;

    private final Report report;
    private final PlayerHistory history;
    private final Runnable back;

    private ReportDetailsGUI(ZReport plugin, Player viewer, Report report, PlayerHistory history, Runnable back) {
        super(plugin, viewer);
        this.report = report;
        this.history = history;
        this.back = back;
        init(54, msg().gui("details.title", "id", String.valueOf(report.id())));
        build();
    }

    /** back null ise ana panele dönülür. */
    public static void open(ZReport plugin, Player viewer, int reportId, Runnable back) {
        plugin.getHistoryManager().loadDetails(reportId, details -> {
            if (!viewer.isOnline()) {
                return;
            }
            if (details.isEmpty()) {
                plugin.getMessages().send(viewer, "report-not-found");
                return;
            }
            new ReportDetailsGUI(plugin, viewer, details.get().report(), details.get().history(), back).open();
        }, error -> plugin.getMessages().send(viewer, "database-error"));
    }

    private String[] placeholders() {
        return GUIUtils.merge(msg().placeholders(report, history.total()), new String[]{
                "count_active", String.valueOf(history.active()),
                "count_reviewed", String.valueOf(history.reviewed()),
                "count_punished", String.valueOf(history.punished())});
    }

    private void build() {
        String[] ph = placeholders();
        String statusKey = report.status().name().toLowerCase(Locale.ROOT);

        set(HEAD, GUIUtils.head(plugin, "gui.details.reported", offline(report.reportedUuid()), ph));
        set(REPORTER, GUIUtils.head(plugin, "gui.details.reporter", offline(report.reporterUuid()), ph));
        set(REASON, GUIUtils.item(plugin, "gui.details.reason", Material.BOOK, ph));
        set(EVIDENCE, report.evidence()
                ? GUIUtils.item(plugin, "gui.details.evidence-yes", Material.LIME_DYE, ph)
                : GUIUtils.item(plugin, "gui.details.evidence-no", Material.RED_DYE, ph));
        set(DATE, GUIUtils.item(plugin, "gui.details.date", Material.CLOCK, ph));
        set(STATUS, GUIUtils.item(plugin, "gui.details.status-" + statusKey, Material.PAPER, ph));
        set(HISTORY, historyItem(ph));

        if (report.status() == ReportStatus.ACTIVE && viewer.hasPermission("zreport.review")) {
            set(REVIEW, GUIUtils.item(plugin, "gui.details.review", Material.LIGHT_BLUE_DYE, ph));
        }
        if (report.status() != ReportStatus.PUNISHED && viewer.hasPermission("zreport.punish")) {
            set(PUNISH, GUIUtils.item(plugin, "gui.details.punish", Material.IRON_SWORD, ph));
        }
        if (viewer.hasPermission("zreport.admin")) {
            set(DELETE, GUIUtils.item(plugin, "gui.details.delete", Material.TNT, ph));
        }
        set(BACK, GUIUtils.item(plugin, "gui.nav.back", Material.ARROW, ph));
        set(CLOSE, GUIUtils.item(plugin, "gui.nav.close", Material.BARRIER, ph));
        fillEmpty();
    }

    private ItemStack historyItem(String[] ph) {
        ItemStack item = GUIUtils.item(plugin, "gui.details.history", Material.WRITABLE_BOOK, ph);
        List<Report> recent = history.recent();
        if (recent.isEmpty()) {
            return item;
        }
        var meta = item.getItemMeta();
        if (meta != null) {
            List<String> lore = meta.getLore() == null ? new java.util.ArrayList<>() : new java.util.ArrayList<>(meta.getLore());
            lore.add(msg().gui("details.recent-header"));
            for (Report previous : recent) {
                lore.add(msg().gui("details.recent-line", msg().placeholders(previous)));
            }
            meta.setLore(lore);
            item.setItemMeta(meta);
        }
        return item;
    }

    @Override
    public String permission() {
        return "zreport.list";
    }

    @Override
    public void onClick(int slot, ClickType click) {
        switch (slot) {
            case HISTORY -> {
                String uuid = report.reportedUuid();
                String name = report.reportedName();
                int id = report.id();
                Runnable origin = back;
                PlayerHistoryGUI.open(plugin, viewer, uuid, name, 1, () -> open(plugin, viewer, id, origin));
            }
            case REVIEW -> startReview(!click.isRightClick());
            case PUNISH -> {
                if (report.status() == ReportStatus.PUNISHED) {
                    return;
                }
                if (!viewer.hasPermission("zreport.punish")) {
                    msg().send(viewer, "no-permission");
                    return;
                }
                later(() -> PunishmentGUI.open(plugin, viewer, report, back));
            }
            case DELETE -> deleteReport();
            case BACK -> goBack();
            case CLOSE -> later(viewer::closeInventory);
            default -> {
            }
        }
    }

    private void goBack() {
        if (back != null) {
            back.run();
        } else {
            ReportDashboardGUI.open(plugin, viewer);
        }
    }

    private void reopen() {
        open(plugin, viewer, report.id(), back);
    }

    private void startReview(boolean askNote) {
        if (report.status() != ReportStatus.ACTIVE) {
            return;
        }
        if (!viewer.hasPermission("zreport.review")) {
            msg().send(viewer, "no-permission");
            return;
        }
        if (!askNote) {
            doReview("");
            return;
        }
        int maxNote = Math.max(1, plugin.getConfig().getInt("settings.max-note-length", 150));
        later(() -> {
            viewer.closeInventory();
            plugin.getChatInput().request(viewer, "prompt-note", maxNote, null, this::doReview, this::reopen);
        });
    }

    private void doReview(String note) {
        GUIManager guiManager = plugin.getGuiManager();
        if (!guiManager.tryLock(viewer)) {
            return;
        }
        plugin.getReportManager().markReviewed(report.id(), viewer, note, updated -> {
            guiManager.unlock(viewer);
            if (updated) {
                msg().send(viewer, "review-success", "id", String.valueOf(report.id()));
                ReportListGUI.open(plugin, viewer, ReportStatus.ACTIVE, 1);
            } else {
                msg().send(viewer, "review-failed");
                reopen();
            }
        }, error -> {
            guiManager.unlock(viewer);
            msg().send(viewer, "database-error");
        });
    }

    private void deleteReport() {
        if (!viewer.hasPermission("zreport.admin")) {
            msg().send(viewer, "no-permission");
            return;
        }
        ConfirmationManager confirmations = plugin.getConfirmations();
        String action = "delete:" + report.id();
        if (!confirmations.consume(viewer, action)) {
            confirmations.request(viewer, action);
            msg().send(viewer, "gui-delete-confirm", "time", String.valueOf(confirmations.timeoutSeconds()));
            return;
        }
        GUIManager guiManager = plugin.getGuiManager();
        if (!guiManager.tryLock(viewer)) {
            return;
        }
        plugin.getReportManager().deleteReport(report.id(), deleted -> {
            guiManager.unlock(viewer);
            if (deleted) {
                msg().send(viewer, "delete-success", "id", String.valueOf(report.id()));
            } else {
                msg().send(viewer, "report-not-found");
            }
            goBack();
        }, error -> {
            guiManager.unlock(viewer);
            msg().send(viewer, "database-error");
        });
    }
}
