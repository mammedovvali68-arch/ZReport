package com.zreport.gui;

import java.util.UUID;

/** Oyuncunun yarım kalan rapor taslağı. Sohbet girişi sırasında GUI durumunu korur. */
public class ReportSession {

    public final UUID targetUuid;
    public final String targetName;
    public String reason = "";
    public boolean evidence = false;

    public ReportSession(UUID targetUuid, String targetName) {
        this.targetUuid = targetUuid;
        this.targetName = targetName;
    }
}
