package com.zreport.gui;

import com.zreport.ZReport;
import com.zreport.managers.ReportManager;
import com.zreport.models.Report;
import com.zreport.utils.GUIUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;

/** Raporlama menüsü: hedef, sebep (sohbetten), kanıt evet/hayır ve RAPORLA butonu. */
public class ReportCreationGUI extends BaseGUI {

    private static final int HEAD = 4;
    private static final int REASON = 10;
    private static final int QUESTION = 12;
    private static final int YES = 13;
    private static final int NO = 14;
    private static final int BACK = 18;
    private static final int SUBMIT = 22;
    private static final int CANCEL = 26;

    private final ReportSession session;

    private ReportCreationGUI(ZReport plugin, Player viewer, ReportSession session) {
        super(plugin, viewer);
        this.session = session;
        init(27, msg().gui("create.title", "player", session.targetName));
        build();
    }

    /** Oyuncunun mevcut taslağıyla menüyü açar; taslak yoksa uyarır. */
    public static void open(ZReport plugin, Player viewer) {
        ReportSession session = plugin.getGuiManager().session(viewer);
        if (session == null) {
            plugin.getMessages().send(viewer, "session-expired");
            return;
        }
        new ReportCreationGUI(plugin, viewer, session).open();
    }

    private boolean evidenceEnabled() {
        return plugin.getConfig().getBoolean("settings.evidence-enabled", true);
    }

    private void build() {
        String reasonText = session.reason.isEmpty() ? msg().gui("create.reason-none") : session.reason;
        set(HEAD, GUIUtils.head(plugin, "gui.create.target", Bukkit.getOfflinePlayer(session.targetUuid),
                "player", session.targetName, "uuid", session.targetUuid.toString()));
        set(REASON, GUIUtils.item(plugin, "gui.create.reason", Material.WRITABLE_BOOK,
                "reason", reasonText, "max", String.valueOf(plugin.getReportManager().maxReasonLength())));
        if (evidenceEnabled()) {
            set(QUESTION, GUIUtils.item(plugin, "gui.create.question", Material.PAPER));
            set(YES, GUIUtils.item(plugin, "gui.create.button-yes", Material.LIME_CONCRETE,
                    "state", msg().gui(session.evidence ? "create.state-selected" : "create.state-unselected")));
            set(NO, GUIUtils.item(plugin, "gui.create.button-no", Material.RED_CONCRETE,
                    "state", msg().gui(session.evidence ? "create.state-unselected" : "create.state-selected")));
        }
        set(BACK, GUIUtils.item(plugin, "gui.nav.back", Material.ARROW));
        set(SUBMIT, GUIUtils.item(plugin, "gui.create.submit", Material.NETHER_STAR));
        set(CANCEL, GUIUtils.item(plugin, "gui.create.cancel", Material.BARRIER));
        fillEmpty();
    }

    @Override
    public String permission() {
        return "zreport.report";
    }

    @Override
    public void onClick(int slot, ClickType click) {
        switch (slot) {
            case REASON -> askReason();
            case YES -> setEvidence(true);
            case NO -> setEvidence(false);
            case SUBMIT -> submit();
            case BACK -> later(() -> PlayerSelectionGUI.open(plugin, viewer, 1));
            case CANCEL -> {
                plugin.getGuiManager().endSession(viewer);
                later(viewer::closeInventory);
            }
            default -> {
            }
        }
    }

    private void setEvidence(boolean value) {
        if (!evidenceEnabled()) {
            return;
        }
        session.evidence = value;
        build();
    }

    private void askReason() {
        ReportManager reports = plugin.getReportManager();
        later(() -> {
            viewer.closeInventory();
            plugin.getChatInput().request(viewer, "prompt-reason", reports.maxReasonLength(),
                    reports::reasonError,
                    input -> {
                        session.reason = input;
                        open(plugin, viewer);
                    },
                    () -> open(plugin, viewer));
        });
    }

    private void submit() {
        GUIManager guiManager = plugin.getGuiManager();
        ReportManager reports = plugin.getReportManager();
        if (session.targetUuid.equals(viewer.getUniqueId())) {
            msg().send(viewer, "cannot-report-yourself");
            return;
        }
        if (!viewer.hasPermission("zreport.admin")) {
            long remaining = plugin.getCooldowns().remainingSeconds(viewer.getUniqueId());
            if (remaining > 0) {
                msg().send(viewer, "cooldown", "time", String.valueOf(remaining));
                return;
            }
        }
        if (!guiManager.tryLock(viewer)) {
            return;
        }
        String reason = session.reason.isEmpty() ? reports.defaultReason() : session.reason;
        Report draft = Report.create(session.targetName, session.targetUuid.toString(), viewer.getName(),
                viewer.getUniqueId().toString(), reason, evidenceEnabled() && session.evidence);
        plugin.getCooldowns().mark(viewer.getUniqueId());
        boolean checkDuplicate = plugin.getConfig().getBoolean("settings.block-duplicate-active", true);
        reports.createReport(draft, checkDuplicate, saved -> {
            guiManager.unlock(viewer);
            if (saved.isEmpty()) {
                plugin.getCooldowns().clear(viewer.getUniqueId());
                msg().send(viewer, "already-reported", "player", session.targetName);
                return;
            }
            viewer.closeInventory();
            guiManager.endSession(viewer);
            msg().send(viewer, "report-success", "player", saved.get().reportedName());
            reports.notifyStaff(saved.get(), viewer);
        }, error -> {
            guiManager.unlock(viewer);
            plugin.getCooldowns().clear(viewer.getUniqueId());
            msg().send(viewer, "database-error");
        });
    }
}
