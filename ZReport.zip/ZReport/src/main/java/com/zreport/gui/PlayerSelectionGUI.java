package com.zreport.gui;

import com.zreport.ZReport;
import com.zreport.utils.GUIUtils;
import com.zreport.utils.Permissions;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** /rapor: çevrimiçi oyuncuların kafalarını listeler (kendisi hariç). */
public class PlayerSelectionGUI extends BaseGUI {

    private static final int PREV = 45;
    private static final int CLOSE = 49;
    private static final int NEXT = 53;

    private final int page;
    private final int pages;
    private final List<Player> shown = new ArrayList<>();

    private PlayerSelectionGUI(ZReport plugin, Player viewer, int requestedPage) {
        super(plugin, viewer);
        List<Player> all = new ArrayList<>();
        for (Player online : Bukkit.getOnlinePlayers()) {
            if (!online.getUniqueId().equals(viewer.getUniqueId())) {
                all.add(online);
            }
        }
        all.sort(Comparator.comparing((Player p) -> p.getName().toLowerCase(Locale.ROOT)));
        int perPage = GUIUtils.LIST_SLOTS.length;
        this.pages = Math.max(1, (int) Math.ceil(all.size() / (double) perPage));
        this.page = Math.min(Math.max(1, requestedPage), pages);
        int from = (page - 1) * perPage;
        for (int i = from; i < Math.min(all.size(), from + perPage); i++) {
            shown.add(all.get(i));
        }
        init(54, msg().gui("select.title", "page", String.valueOf(page), "pages", String.valueOf(pages)));
        build();
    }

    public static void open(ZReport plugin, Player viewer, int page) {
        new PlayerSelectionGUI(plugin, viewer, page).open();
    }

    private void build() {
        String[] pageInfo = {"page", String.valueOf(page), "pages", String.valueOf(pages)};
        if (shown.isEmpty()) {
            set(22, GUIUtils.item(plugin, "gui.select.empty", Material.BARRIER));
        }
        for (int i = 0; i < shown.size(); i++) {
            Player target = shown.get(i);
            set(GUIUtils.LIST_SLOTS[i], GUIUtils.head(plugin, "gui.select.item", target,
                    "player", target.getName(),
                    "world", target.getWorld().getName(),
                    "ping", String.valueOf(target.getPing())));
        }
        if (page > 1) {
            set(PREV, GUIUtils.item(plugin, "gui.nav.prev", Material.ARROW, pageInfo));
        }
        if (page < pages) {
            set(NEXT, GUIUtils.item(plugin, "gui.nav.next", Material.ARROW, pageInfo));
        }
        set(CLOSE, GUIUtils.item(plugin, "gui.nav.close", Material.BARRIER, pageInfo));
        fillEmpty();
    }

    @Override
    public String permission() {
        return Permissions.REPORT;
    }

    @Override
    public void onClick(int slot, ClickType click) {
        if (slot == PREV && page > 1) {
            later(() -> open(plugin, viewer, page - 1));
            return;
        }
        if (slot == NEXT && page < pages) {
            later(() -> open(plugin, viewer, page + 1));
            return;
        }
        if (slot == CLOSE) {
            later(viewer::closeInventory);
            return;
        }
        for (int i = 0; i < shown.size(); i++) {
            if (GUIUtils.LIST_SLOTS[i] != slot) {
                continue;
            }
            Player target = shown.get(i);
            if (!target.isOnline()) {
                msg().send(viewer, "target-left");
                later(() -> open(plugin, viewer, page));
                return;
            }
            plugin.getGuiManager().startSession(viewer, target.getUniqueId(), target.getName());
            later(() -> ReportCreationGUI.open(plugin, viewer));
            return;
        }
    }
}
