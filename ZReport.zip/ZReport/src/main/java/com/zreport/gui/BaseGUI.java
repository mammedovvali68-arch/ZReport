package com.zreport.gui;

import com.zreport.ZReport;
import com.zreport.managers.MessageManager;
import com.zreport.utils.GUIUtils;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

/** Bütün ZReport menülerinin tabanı. Her menü hangi oyuncuya ait olduğunu holder üzerinden taşır. */
public abstract class BaseGUI implements InventoryHolder {

    protected final ZReport plugin;
    protected final Player viewer;
    protected Inventory inventory;

    protected BaseGUI(ZReport plugin, Player viewer) {
        this.plugin = plugin;
        this.viewer = viewer;
    }

    /** Menüyü kullanmak için gereken yetki. */
    public abstract String permission();

    public abstract void onClick(int slot, ClickType click);

    protected void init(int size, String title) {
        this.inventory = Bukkit.createInventory(this, size, title);
    }

    public void open() {
        viewer.openInventory(inventory);
    }

    protected void set(int slot, ItemStack item) {
        inventory.setItem(slot, item);
    }

    /** Boş kalan slotları dekoratif cam panelle doldurur. */
    protected void fillEmpty() {
        ItemStack filler = GUIUtils.filler(plugin);
        for (int i = 0; i < inventory.getSize(); i++) {
            if (inventory.getItem(i) == null) {
                inventory.setItem(i, filler);
            }
        }
    }

    protected MessageManager msg() {
        return plugin.getMessages();
    }

    protected void later(Runnable task) {
        Bukkit.getScheduler().runTask(plugin, task);
    }

    protected static OfflinePlayer offline(String uuid) {
        if (uuid == null) {
            return null;
        }
        try {
            return Bukkit.getOfflinePlayer(UUID.fromString(uuid));
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }

    public Player viewer() {
        return viewer;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
