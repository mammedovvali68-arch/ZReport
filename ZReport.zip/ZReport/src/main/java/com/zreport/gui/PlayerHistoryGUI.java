package com.zreport.gui;

import com.zreport.ZReport;
import com.zreport.managers.ReportHistoryManager.HistoryPage;
import com.zreport.models.Report;
import com.zreport.models.ReportPage;
import com.zreport.utils.GUIUtils;
import com.zreport.utils.Permissions;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Bir oyuncunun bütün raporları (her durumda) ve özet sayıları. */
public class PlayerHistoryGUI extends BaseGUI {

    private static final int HEAD = 4;
    private static final int PREV = 45;
    private static final int BACK = 48;
    private static final int CLOSE = 50;
    private static final int NEXT = 53;

    private final String uuid;
    private final String name;
    private final HistoryPage data;
    private final Runnable back;
    private final Map<Integer, Integer> slotToReportId = new HashMap<>();

    private PlayerHistoryGUI(ZReport plugin, Player viewer, String uuid, String name, HistoryPage data, Runnable back) {
        super(plugin, viewer);
        this.uuid = uuid;
        this.name = name;
        this.data = data;
        this.back = back;
        ReportPage page = data.page();
        init(54, msg().gui("history.title", "player", name,
                "page", String.valueOf(page.page()), "pages", String.valueOf(page.totalPages())));
        build();
    }

    public static void open(ZReport plugin, Player viewer, String uuid, String name, int page, Runnable back) {
        plugin.getHistoryManager().loadHistoryPage(uuid, name, page, GUIUtils.LIST_SLOTS.length, data -> {
            if (viewer.isOnline()) {
                new PlayerHistoryGUI(plugin, viewer, uuid, name, data, back).open();
            }
        }, error -> plugin.getMessages().send(viewer, "database-error"));
    }

    private void build() {
        ReportPage page = data.page();
        var summary = data.summary();
        String[] pageInfo = {"page", String.valueOf(page.page()), "pages", String.valueOf(page.totalPages()),
                "player", name, "total", String.valueOf(summary.total()),
                "count_active", String.valueOf(summary.active()),
                "count_reviewed", String.valueOf(summary.reviewed()),
                "count_punished", String.valueOf(summary.punished())};
        set(HEAD, GUIUtils.head(plugin, "gui.history.summary", offline(uuid), pageInfo));
        for (int i = 0; i < page.reports().size() && i < GUIUtils.LIST_SLOTS.length; i++) {
            Report report = page.reports().get(i);
            String path = "gui.history.item-" + report.status().name().toLowerCase(Locale.ROOT);
            set(GUIUtils.LIST_SLOTS[i], GUIUtils.item(plugin, path, Material.PAPER, msg().placeholders(report)));
            slotToReportId.put(GUIUtils.LIST_SLOTS[i], report.id());
        }
        if (page.page() > 1) {
            set(PREV, GUIUtils.item(plugin, "gui.nav.prev", Material.ARROW, pageInfo));
        }
        if (page.page() < page.totalPages()) {
            set(NEXT, GUIUtils.item(plugin, "gui.nav.next", Material.ARROW, pageInfo));
        }
        set(BACK, GUIUtils.item(plugin, "gui.nav.back", Material.ARROW, pageInfo));
        set(CLOSE, GUIUtils.item(plugin, "gui.nav.close", Material.BARRIER, pageInfo));
        fillEmpty();
    }

    @Override
    public String permission() {
        return Permissions.LIST;
    }

    @Override
    public void onClick(int slot, ClickType click) {
        ReportPage page = data.page();
        switch (slot) {
            case PREV -> {
                if (page.page() > 1) {
                    open(plugin, viewer, uuid, name, page.page() - 1, back);
                }
            }
            case NEXT -> {
                if (page.page() < page.totalPages()) {
                    open(plugin, viewer, uuid, name, page.page() + 1, back);
                }
            }
            case BACK -> {
                if (back != null) {
                    back.run();
                } else {
                    ReportDashboardGUI.open(plugin, viewer);
                }
            }
            case CLOSE -> later(viewer::closeInventory);
            default -> {
                Integer id = slotToReportId.get(slot);
                if (id != null) {
                    int current = page.page();
                    ReportDetailsGUI.open(plugin, viewer, id, () -> open(plugin, viewer, uuid, name, current, back));
                }
            }
        }
    }
}
