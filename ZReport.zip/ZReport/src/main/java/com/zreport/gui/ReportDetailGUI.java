package com.zreport.gui;

import com.zreport.ZReport;
import com.zreport.managers.MessageManager;
import com.zreport.models.Report;
import com.zreport.utils.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.ArrayList;
import java.util.List;

/** Tek bir raporun ayrıntı menüsü (27 slot). */
public class ReportDetailGUI implements InventoryHolder {

    public static final int REPORTED_SLOT = 10;
    public static final int REASON_SLOT = 12;
    public static final int REPORTER_SLOT = 14;
    public static final int DATE_SLOT = 16;
    public static final int BACK_SLOT = 22;
    public static final int DELETE_SLOT = 26;

    private final Report report;
    private final int returnPage;
    private final Inventory inventory;

    private ReportDetailGUI(ZReport plugin, Report report, int returnPage, boolean canDelete) {
        this.report = report;
        this.returnPage = returnPage;
        MessageManager messages = plugin.getMessages();
        String[] ph = messages.placeholders(report);
        this.inventory = Bukkit.createInventory(this, 27, messages.raw("gui-detail-title", ph));

        for (int slot = 0; slot < 27; slot++) {
            inventory.setItem(slot, ItemBuilder.filler());
        }
        inventory.setItem(REPORTED_SLOT, ItemBuilder.create(Material.NAME_TAG,
                messages.raw("gui-detail-reported", ph),
                List.of(messages.raw("gui-detail-uuid", "uuid", messages.placeholders(report)[5]))));

        List<String> reasonLore = new ArrayList<>();
        for (String line : TextUtil.wrap(report.reason(), 32)) {
            reasonLore.add("\u00A7f" + line);
        }
        inventory.setItem(REASON_SLOT, ItemBuilder.create(Material.BOOK, messages.raw("gui-detail-reason", ph), reasonLore));

        inventory.setItem(REPORTER_SLOT, ItemBuilder.create(Material.PAPER,
                messages.raw("gui-detail-reporter", ph),
                List.of(messages.raw("gui-detail-uuid", "uuid", messages.placeholders(report)[9]))));

        inventory.setItem(DATE_SLOT, ItemBuilder.create(Material.CLOCK,
                messages.raw("gui-detail-date", ph), messages.rawList("gui-detail-date-lore", ph)));

        inventory.setItem(BACK_SLOT, ItemBuilder.create(Material.ARROW, messages.raw("gui-back-name"), null));

        if (canDelete) {
            inventory.setItem(DELETE_SLOT, ItemBuilder.create(Material.TNT,
                    messages.raw("gui-delete-name"), messages.rawList("gui-delete-lore")));
        }
    }

    public static void open(ZReport plugin, Player player, int reportId, int returnPage) {
        MessageManager messages = plugin.getMessages();
        plugin.getReportManager().getReport(reportId, optional -> {
            if (!player.isOnline()) {
                return;
            }
            if (optional.isEmpty()) {
                messages.send(player, "report-not-found");
                return;
            }
            boolean canDelete = player.hasPermission("zreport.admin");
            player.openInventory(new ReportDetailGUI(plugin, optional.get(), returnPage, canDelete).getInventory());
        }, error -> messages.send(player, "database-error"));
    }

    public Report report() {
        return report;
    }

    public int returnPage() {
        return returnPage;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
