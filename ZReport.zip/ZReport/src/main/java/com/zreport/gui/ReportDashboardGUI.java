package com.zreport.gui;

import com.zreport.ZReport;
import com.zreport.models.ReportStatus;
import com.zreport.utils.GUIUtils;
import com.zreport.utils.Permissions;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;

/** /raporlist ana paneli: ACTIVE, REVIEWED ve PUNISHED kategorileri. */
public class ReportDashboardGUI extends BaseGUI {

    private static final int ACTIVE = 11;
    private static final int REVIEWED = 13;
    private static final int PUNISHED = 15;
    private static final int CLOSE = 22;

    private ReportDashboardGUI(ZReport plugin, Player viewer, int[] counts) {
        super(plugin, viewer);
        init(27, msg().gui("dashboard.title"));
        set(ACTIVE, GUIUtils.item(plugin, "gui.dashboard.active", Material.ORANGE_CONCRETE,
                "count", String.valueOf(counts[ReportStatus.ACTIVE.ordinal()])));
        set(REVIEWED, GUIUtils.item(plugin, "gui.dashboard.reviewed", Material.LIGHT_BLUE_CONCRETE,
                "count", String.valueOf(counts[ReportStatus.REVIEWED.ordinal()])));
        set(PUNISHED, GUIUtils.item(plugin, "gui.dashboard.punished", Material.RED_CONCRETE,
                "count", String.valueOf(counts[ReportStatus.PUNISHED.ordinal()])));
        set(CLOSE, GUIUtils.item(plugin, "gui.nav.close", Material.BARRIER));
        fillEmpty();
    }

    public static void open(ZReport plugin, Player viewer) {
        plugin.getReportManager().getStatusCounts(counts -> {
            if (viewer.isOnline()) {
                new ReportDashboardGUI(plugin, viewer, counts).open();
            }
        }, error -> plugin.getMessages().send(viewer, "database-error"));
    }

    @Override
    public String permission() {
        return Permissions.LIST;
    }

    @Override
    public void onClick(int slot, ClickType click) {
        switch (slot) {
            case ACTIVE -> ReportListGUI.open(plugin, viewer, ReportStatus.ACTIVE, 1);
            case REVIEWED -> ReportListGUI.open(plugin, viewer, ReportStatus.REVIEWED, 1);
            case PUNISHED -> ReportListGUI.open(plugin, viewer, ReportStatus.PUNISHED, 1);
            case CLOSE -> later(viewer::closeInventory);
            default -> {
            }
        }
    }
}
