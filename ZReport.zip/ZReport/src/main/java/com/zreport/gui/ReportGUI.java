package com.zreport.gui;

import com.zreport.ZReport;
import com.zreport.managers.MessageManager;
import com.zreport.models.Report;
import com.zreport.models.ReportPage;
import com.zreport.utils.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Sayfalı rapor listesi menüsü (54 slot, sayfa başına 28 rapor). */
public class ReportGUI implements InventoryHolder {

    public static final int[] REPORT_SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34,
            37, 38, 39, 40, 41, 42, 43};
    public static final int PREV_SLOT = 45;
    public static final int INFO_SLOT = 49;
    public static final int NEXT_SLOT = 53;

    private final ZReport plugin;
    private final ReportPage page;
    private final Inventory inventory;
    private final Map<Integer, Integer> slotToReportId = new HashMap<>();

    private ReportGUI(ZReport plugin, ReportPage page) {
        this.plugin = plugin;
        this.page = page;
        MessageManager messages = plugin.getMessages();
        String title = messages.raw("gui-list-title",
                "page", String.valueOf(page.page()), "pages", String.valueOf(page.totalPages()));
        this.inventory = Bukkit.createInventory(this, 54, title);
        build();
    }

    public static void open(ZReport plugin, Player player, int requestedPage) {
        MessageManager messages = plugin.getMessages();
        plugin.getReportManager().getPage(requestedPage, REPORT_SLOTS.length, result -> {
            if (!player.isOnline()) {
                return;
            }
            if (result.totalCount() == 0) {
                player.closeInventory();
                messages.send(player, "report-list-empty");
                return;
            }
            player.openInventory(new ReportGUI(plugin, result).getInventory());
        }, error -> messages.send(player, "database-error"));
    }

    private void build() {
        MessageManager messages = plugin.getMessages();
        List<Report> reports = page.reports();
        for (int i = 0; i < reports.size() && i < REPORT_SLOTS.length; i++) {
            Report report = reports.get(i);
            ItemStack item = ItemBuilder.create(Material.PAPER,
                    messages.raw("gui-item-name", messages.placeholders(report)), buildLore(report));
            inventory.setItem(REPORT_SLOTS[i], item);
            slotToReportId.put(REPORT_SLOTS[i], report.id());
        }
        for (int slot = 45; slot < 54; slot++) {
            inventory.setItem(slot, ItemBuilder.filler());
        }
        String[] pageValues = {"page", String.valueOf(page.page()), "pages", String.valueOf(page.totalPages()),
                "total", String.valueOf(page.totalCount())};
        if (page.page() > 1) {
            inventory.setItem(PREV_SLOT, ItemBuilder.create(Material.ARROW, messages.raw("gui-prev-name", pageValues), null));
        }
        if (page.page() < page.totalPages()) {
            inventory.setItem(NEXT_SLOT, ItemBuilder.create(Material.ARROW, messages.raw("gui-next-name", pageValues), null));
        }
        inventory.setItem(INFO_SLOT, ItemBuilder.create(Material.BOOK,
                messages.raw("gui-info-name", pageValues), messages.rawList("gui-info-lore", pageValues)));
    }

    private List<String> buildLore(Report report) {
        MessageManager messages = plugin.getMessages();
        List<String> lore = new ArrayList<>();
        for (String template : plugin.getConfig().getStringList("messages.gui-item-lore")) {
            if (template.contains("%reason%")) {
                List<String> chunks = TextUtil.wrap(report.reason(), 32);
                for (int i = 0; i < chunks.size(); i++) {
                    if (i == 0) {
                        lore.add(messages.apply(template, messages.placeholders(report.withReason(chunks.get(0)))));
                    } else {
                        lore.add("\u00A7f" + chunks.get(i));
                    }
                }
            } else {
                lore.add(messages.apply(template, messages.placeholders(report)));
            }
        }
        return lore;
    }

    public int page() {
        return page.page();
    }

    public int totalPages() {
        return page.totalPages();
    }

    /** Verilen slottaki raporun ID'si, yoksa null. */
    public Integer reportIdAt(int slot) {
        return slotToReportId.get(slot);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
