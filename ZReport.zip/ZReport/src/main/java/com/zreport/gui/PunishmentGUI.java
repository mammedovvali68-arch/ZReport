package com.zreport.gui;

import com.zreport.ZReport;
import com.zreport.models.PunishmentType;
import com.zreport.models.Report;
import com.zreport.models.ReportStatus;
import com.zreport.punishment.PunishmentManager.DurationOption;
import com.zreport.utils.GUIUtils;
import com.zreport.utils.Permissions;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;

import java.util.List;

/** Ceza menüsü: ceza türü seçimi, TEMPBAN için süre seçimi, ardından sohbetten isteğe bağlı sebep. */
public class PunishmentGUI extends BaseGUI {

    private static final int[] TYPE_SLOTS = {10, 11, 13, 15, 16};
    private static final int[] DURATION_SLOTS = {10, 11, 12, 13, 14, 15, 16};
    private static final int HEAD = 4;
    private static final int BACK = 18;
    private static final int CLOSE = 26;

    private final Report report;
    private final Runnable detailsBack;
    private final PunishmentType pendingType;
    private final List<PunishmentType> types;
    private final List<DurationOption> durations;

    private PunishmentGUI(ZReport plugin, Player viewer, Report report, Runnable detailsBack,
                          PunishmentType pendingType) {
        super(plugin, viewer);
        this.report = report;
        this.detailsBack = detailsBack;
        this.pendingType = pendingType;
        this.types = plugin.getPunishmentManager().enabledTypes();
        this.durations = plugin.getPunishmentManager().durations();
        init(27, msg().gui(pendingType == null ? "punish.title" : "punish.duration-title",
                "player", report.reportedName()));
        build();
    }

    public static void open(ZReport plugin, Player viewer, Report report, Runnable detailsBack) {
        new PunishmentGUI(plugin, viewer, report, detailsBack, null).open();
    }

    private void build() {
        String[] ph = {"player", report.reportedName(), "id", String.valueOf(report.id()),
                "reason", report.reason()};
        set(HEAD, GUIUtils.head(plugin, "gui.punish.target", offline(report.reportedUuid()), ph));
        if (pendingType == null) {
            for (int i = 0; i < types.size() && i < TYPE_SLOTS.length; i++) {
                set(TYPE_SLOTS[i], GUIUtils.item(plugin, "punishment.types." + types.get(i).name(),
                        Material.PAPER, ph));
            }
        } else {
            for (int i = 0; i < durations.size() && i < DURATION_SLOTS.length; i++) {
                set(DURATION_SLOTS[i], GUIUtils.item(plugin, "gui.punish.duration", Material.CLOCK,
                        GUIUtils.merge(ph, new String[]{"label", durations.get(i).label()})));
            }
        }
        set(BACK, GUIUtils.item(plugin, "gui.nav.back", Material.ARROW, ph));
        set(CLOSE, GUIUtils.item(plugin, "gui.nav.close", Material.BARRIER, ph));
        fillEmpty();
    }

    @Override
    public String permission() {
        return Permissions.PUNISH;
    }

    @Override
    public void onClick(int slot, ClickType click) {
        if (slot == CLOSE) {
            later(viewer::closeInventory);
            return;
        }
        if (slot == BACK) {
            if (pendingType == null) {
                ReportDetailsGUI.open(plugin, viewer, report.id(), detailsBack);
            } else {
                later(() -> open(plugin, viewer, report, detailsBack));
            }
            return;
        }
        if (pendingType == null) {
            for (int i = 0; i < types.size() && i < TYPE_SLOTS.length; i++) {
                if (TYPE_SLOTS[i] == slot) {
                    chooseType(types.get(i));
                    return;
                }
            }
        } else {
            for (int i = 0; i < durations.size() && i < DURATION_SLOTS.length; i++) {
                if (DURATION_SLOTS[i] == slot) {
                    askReason(PunishmentType.TEMPBAN, durations.get(i).seconds());
                    return;
                }
            }
        }
    }

    private void chooseType(PunishmentType type) {
        if (type == PunishmentType.TEMPBAN) {
            if (durations.isEmpty()) {
                msg().send(viewer, "punish-no-durations");
                return;
            }
            later(() -> new PunishmentGUI(plugin, viewer, report, detailsBack, PunishmentType.TEMPBAN).open());
            return;
        }
        askReason(type, 0);
    }

    private void askReason(PunishmentType type, long seconds) {
        if (!requirePermission(Permissions.PUNISH)) {
            return;
        }
        int max = plugin.getReportManager().maxReasonLength();
        later(() -> {
            viewer.closeInventory();
            plugin.getChatInput().request(viewer, "prompt-punish-reason", max, null,
                    input -> execute(type, input.isEmpty() ? plugin.getPunishmentManager().defaultReason() : input, seconds),
                    () -> ReportDetailsGUI.open(plugin, viewer, report.id(), detailsBack));
        });
    }

    private void execute(PunishmentType type, String reason, long seconds) {
        GUIManager guiManager = plugin.getGuiManager();
        // Sebep sohbetten girildiği için yetki işlem anında tekrar doğrulanır (PunishmentManager de doğrular).
        if (!requirePermission(Permissions.PUNISH) || !guiManager.tryLock(viewer)) {
            return;
        }
        plugin.getPunishmentManager().apply(viewer, report, type, reason, seconds, error -> {
            guiManager.unlock(viewer);
            if (!viewer.isOnline()) {
                return;
            }
            if (error == null) {
                msg().send(viewer, "punish-success", "player", report.reportedName(),
                        "type", msg().typeLabel(type.name()), "reason", reason);
                ReportListGUI.open(plugin, viewer, ReportStatus.PUNISHED, 1);
            } else {
                msg().send(viewer, error, "player", report.reportedName());
                ReportDetailsGUI.open(plugin, viewer, report.id(), detailsBack);
            }
        });
    }
}
