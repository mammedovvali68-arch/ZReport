package com.zreport.gui;

import com.zreport.ZReport;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Oyuncu başına rapor taslakları, tıklama hız sınırı ve işlem kilitleri. */
public class GUIManager {

    private static final long LOCK_TIMEOUT_MS = 10_000L;

    private final ZReport plugin;
    private final Map<UUID, ReportSession> sessions = new ConcurrentHashMap<>();
    private final Map<UUID, Long> lastClick = new ConcurrentHashMap<>();
    private final Map<UUID, Long> locks = new ConcurrentHashMap<>();

    public GUIManager(ZReport plugin) {
        this.plugin = plugin;
    }

    /** Çok hızlı tıklamaları ve devam eden bir işlem sırasındaki tıklamaları reddeder. */
    public boolean allowClick(Player player) {
        long now = System.currentTimeMillis();
        UUID id = player.getUniqueId();
        if (isLocked(id, now)) {
            return false;
        }
        long delay = Math.max(0, plugin.getConfig().getLong("settings.click-delay-ms", 250));
        Long last = lastClick.get(id);
        if (last != null && now - last < delay) {
            return false;
        }
        lastClick.put(id, now);
        return true;
    }

    private boolean isLocked(UUID id, long now) {
        Long since = locks.get(id);
        if (since == null) {
            return false;
        }
        if (now - since > LOCK_TIMEOUT_MS) {
            locks.remove(id);
            return false;
        }
        return true;
    }

    /** Asenkron bir işlem başlatmadan önce çağrılır; zaten bir işlem sürüyorsa false döner. */
    public boolean tryLock(Player player) {
        long now = System.currentTimeMillis();
        UUID id = player.getUniqueId();
        if (isLocked(id, now)) {
            return false;
        }
        locks.put(id, now);
        return true;
    }

    public void unlock(Player player) {
        locks.remove(player.getUniqueId());
    }

    public ReportSession startSession(Player player, UUID targetUuid, String targetName) {
        ReportSession session = new ReportSession(targetUuid, targetName);
        sessions.put(player.getUniqueId(), session);
        return session;
    }

    public ReportSession session(Player player) {
        return sessions.get(player.getUniqueId());
    }

    public void endSession(Player player) {
        sessions.remove(player.getUniqueId());
    }

    public void cleanup(UUID id) {
        sessions.remove(id);
        lastClick.remove(id);
        locks.remove(id);
    }
}
