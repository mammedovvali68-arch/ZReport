package com.zreport.gui;

import com.zreport.ZReport;
import com.zreport.models.Report;
import com.zreport.models.ReportPage;
import com.zreport.models.ReportStatus;
import com.zreport.utils.GUIUtils;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Bir kategorideki (ACTIVE / REVIEWED / PUNISHED) raporların sayfalı listesi. */
public class ReportListGUI extends BaseGUI {

    private static final int PREV = 45;
    private static final int CAT_ACTIVE = 46;
    private static final int CAT_REVIEWED = 47;
    private static final int CAT_PUNISHED = 48;
    private static final int INFO = 49;
    private static final int BACK = 50;
    private static final int CLOSE = 52;
    private static final int NEXT = 53;

    private final ReportStatus status;
    private final ReportPage data;
    private final Map<Integer, Integer> slotToReportId = new HashMap<>();

    private ReportListGUI(ZReport plugin, Player viewer, ReportStatus status, ReportPage data) {
        super(plugin, viewer);
        this.status = status;
        this.data = data;
        init(54, msg().gui("list.title", "status", msg().statusName(status),
                "page", String.valueOf(data.page()), "pages", String.valueOf(data.totalPages())));
        build();
    }

    public static void open(ZReport plugin, Player viewer, ReportStatus status, int page) {
        plugin.getReportManager().getPage(status, page, GUIUtils.LIST_SLOTS.length, data -> {
            if (viewer.isOnline()) {
                new ReportListGUI(plugin, viewer, status, data).open();
            }
        }, error -> plugin.getMessages().send(viewer, "database-error"));
    }

    private static String lower(ReportStatus status) {
        return status.name().toLowerCase(Locale.ROOT);
    }

    private void build() {
        String[] pageInfo = {"page", String.valueOf(data.page()), "pages", String.valueOf(data.totalPages()),
                "total", String.valueOf(data.totalCount()), "status", msg().statusName(status)};
        if (data.reports().isEmpty()) {
            set(22, GUIUtils.item(plugin, "gui.list.empty", Material.BARRIER, pageInfo));
        }
        for (int i = 0; i < data.reports().size() && i < GUIUtils.LIST_SLOTS.length; i++) {
            Report report = data.reports().get(i);
            String[] ph = msg().placeholders(report, data.targetTotals().getOrDefault(report.id(), 0));
            String path = "gui.list.item-" + lower(status);
            ItemStack item = report.reportedUuid() != null
                    ? GUIUtils.head(plugin, path, offline(report.reportedUuid()), ph)
                    : GUIUtils.item(plugin, path, Material.PLAYER_HEAD, ph);
            set(GUIUtils.LIST_SLOTS[i], item);
            slotToReportId.put(GUIUtils.LIST_SLOTS[i], report.id());
        }
        if (data.page() > 1) {
            set(PREV, GUIUtils.item(plugin, "gui.nav.prev", Material.ARROW, pageInfo));
        }
        if (data.page() < data.totalPages()) {
            set(NEXT, GUIUtils.item(plugin, "gui.nav.next", Material.ARROW, pageInfo));
        }
        set(CAT_ACTIVE, category(ReportStatus.ACTIVE, Material.ORANGE_CONCRETE));
        set(CAT_REVIEWED, category(ReportStatus.REVIEWED, Material.LIGHT_BLUE_CONCRETE));
        set(CAT_PUNISHED, category(ReportStatus.PUNISHED, Material.RED_CONCRETE));
        set(INFO, GUIUtils.item(plugin, "gui.nav.info", Material.BOOK, pageInfo));
        set(BACK, GUIUtils.item(plugin, "gui.nav.back", Material.ARROW, pageInfo));
        set(CLOSE, GUIUtils.item(plugin, "gui.nav.close", Material.BARRIER, pageInfo));
        fillEmpty();
    }

    private ItemStack category(ReportStatus target, Material fallback) {
        return GUIUtils.item(plugin, "gui.list.cat-" + lower(target), fallback,
                "count", String.valueOf(data.counts()[target.ordinal()]),
                "state", msg().gui(target == status ? "list.state-selected" : "list.state-unselected"));
    }

    @Override
    public String permission() {
        return "zreport.list";
    }

    @Override
    public void onClick(int slot, ClickType click) {
        switch (slot) {
            case PREV -> {
                if (data.page() > 1) {
                    open(plugin, viewer, status, data.page() - 1);
                }
            }
            case NEXT -> {
                if (data.page() < data.totalPages()) {
                    open(plugin, viewer, status, data.page() + 1);
                }
            }
            case CAT_ACTIVE -> open(plugin, viewer, ReportStatus.ACTIVE, 1);
            case CAT_REVIEWED -> open(plugin, viewer, ReportStatus.REVIEWED, 1);
            case CAT_PUNISHED -> open(plugin, viewer, ReportStatus.PUNISHED, 1);
            case BACK -> ReportDashboardGUI.open(plugin, viewer);
            case CLOSE -> later(viewer::closeInventory);
            default -> {
                Integer id = slotToReportId.get(slot);
                if (id != null) {
                    int page = data.page();
                    ReportDetailsGUI.open(plugin, viewer, id, () -> open(plugin, viewer, status, page));
                }
            }
        }
    }
}
