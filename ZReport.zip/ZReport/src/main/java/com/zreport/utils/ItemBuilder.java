package com.zreport.utils;

import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.List;

/** ItemMeta tek seferde uygulanır (her çağrıda meta kopyalanmaz). */
public final class ItemBuilder {

    private final ItemStack item;
    private final ItemMeta meta;

    private ItemBuilder(Material material) {
        this.item = new ItemStack(material);
        this.meta = item.getItemMeta();
    }

    public static ItemBuilder of(Material material) {
        return new ItemBuilder(material);
    }

    /** Oyuncu kafası. owner null ise sahipsiz kafa döner. */
    public static ItemBuilder head(OfflinePlayer owner) {
        ItemBuilder builder = new ItemBuilder(Material.PLAYER_HEAD);
        if (owner != null && builder.meta instanceof SkullMeta skull) {
            skull.setOwningPlayer(owner);
        }
        return builder;
    }

    @SuppressWarnings("deprecation")
    public ItemBuilder name(String name) {
        if (meta != null) {
            meta.setDisplayName(name);
        }
        return this;
    }

    @SuppressWarnings("deprecation")
    public ItemBuilder lore(List<String> lore) {
        if (meta != null && lore != null && !lore.isEmpty()) {
            meta.setLore(lore);
        }
        return this;
    }

    public ItemStack build() {
        if (meta != null) {
            item.setItemMeta(meta);
        }
        return item;
    }
}
