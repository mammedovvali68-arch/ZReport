package com.zreport.utils;

import org.bukkit.configuration.file.FileConfiguration;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

/** Tarih/saat biçimleri config.yml'den okunur; sunucunun yerel saat dilimi kullanılır. */
public final class DateUtils {

    private static volatile DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    private static volatile DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("HH:mm");
    private static volatile DateTimeFormatter dateTimeFormat = DateTimeFormatter.ofPattern("dd.MM.yyyy - HH:mm");
    private static volatile String dayUnit = "gün";
    private static volatile String hourUnit = "saat";
    private static volatile String minuteUnit = "dakika";

    private DateUtils() {
    }

    public static void configure(FileConfiguration config) {
        dateFormat = formatter(config.getString("settings.date-format"), dateFormat);
        timeFormat = formatter(config.getString("settings.time-format"), timeFormat);
        dateTimeFormat = formatter(config.getString("settings.datetime-format"), dateTimeFormat);
        dayUnit = config.getString("settings.duration-units.day", "gün");
        hourUnit = config.getString("settings.duration-units.hour", "saat");
        minuteUnit = config.getString("settings.duration-units.minute", "dakika");
    }

    private static DateTimeFormatter formatter(String pattern, DateTimeFormatter fallback) {
        if (pattern == null || pattern.isBlank()) {
            return fallback;
        }
        try {
            return DateTimeFormatter.ofPattern(pattern);
        } catch (IllegalArgumentException ex) {
            return fallback;
        }
    }

    private static String format(DateTimeFormatter formatter, long millis) {
        if (millis <= 0) {
            return "-";
        }
        return formatter.format(Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()));
    }

    public static String date(long millis) {
        return format(dateFormat, millis);
    }

    public static String time(long millis) {
        return format(timeFormat, millis);
    }

    public static String dateTime(long millis) {
        return format(dateTimeFormat, millis);
    }

    /** "3 gün 2 saat" gibi okunabilir süre. */
    public static String human(long seconds) {
        if (seconds <= 0) {
            return "-";
        }
        long days = seconds / 86400;
        long hours = (seconds % 86400) / 3600;
        long minutes = (seconds % 3600) / 60;
        StringBuilder sb = new StringBuilder();
        if (days > 0) {
            sb.append(days).append(' ').append(dayUnit).append(' ');
        }
        if (hours > 0) {
            sb.append(hours).append(' ').append(hourUnit).append(' ');
        }
        if (minutes > 0 || sb.length() == 0) {
            sb.append(Math.max(minutes, 1)).append(' ').append(minuteUnit).append(' ');
        }
        return sb.toString().trim();
    }

    /** Harici ban komutları için kısa biçim: 7d, 6h, 30m. */
    public static String compact(long seconds) {
        if (seconds % 86400 == 0 && seconds >= 86400) {
            return (seconds / 86400) + "d";
        }
        if (seconds % 3600 == 0 && seconds >= 3600) {
            return (seconds / 3600) + "h";
        }
        return Math.max(1, seconds / 60) + "m";
    }
}
