package com.zreport.utils;

/** Bütün yetki düğümleri tek yerde. */
public final class Permissions {

    public static final String REPORT = "zreport.report";
    public static final String LIST = "zreport.list";
    public static final String REVIEW = "zreport.review";
    public static final String PUNISH = "zreport.punish";
    public static final String ADMIN = "zreport.admin";

    private Permissions() {
    }
}
