package com.zreport.utils;

import java.util.logging.Level;
import java.util.logging.Logger;

/** Düzenli log yardımcısı. Stack trace yalnızca settings.debug açıkken yazılır. */
public final class Log {

    private static volatile Logger logger = Logger.getLogger("ZReport");
    private static volatile boolean debugEnabled;

    private Log() {
    }

    public static void init(Logger pluginLogger, boolean debug) {
        logger = pluginLogger;
        debugEnabled = debug;
    }

    public static void info(String message) {
        logger.info(message);
    }

    public static void warn(String message) {
        logger.warning(message);
    }

    /** Tek satırlık hata; ayrıntılı stack trace yalnızca debug modunda. */
    public static void error(String message, Throwable throwable) {
        if (throwable == null) {
            logger.severe(message);
            return;
        }
        logger.severe(message + ": " + throwable.getClass().getSimpleName() + ": " + throwable.getMessage());
        if (debugEnabled) {
            logger.log(Level.SEVERE, "Stack trace", throwable);
        }
    }

    public static void debug(String message) {
        if (debugEnabled) {
            logger.info("[DEBUG] " + message);
        }
    }

    public static boolean isDebug() {
        return debugEnabled;
    }
}
