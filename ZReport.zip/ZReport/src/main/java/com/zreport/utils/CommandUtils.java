package com.zreport.utils;

/** Komutlar için ortak doğrulamalar. */
public final class CommandUtils {

    private CommandUtils() {
    }

    /** "12" veya "#12" biçimindeki rapor ID'sini okur. Geçersizse (sayı değil, sıfır, negatif) -1 döner. */
    public static int parseReportId(String text) {
        if (text == null) {
            return -1;
        }
        String value = text.startsWith("#") ? text.substring(1) : text;
        try {
            int id = Integer.parseInt(value);
            return id > 0 ? id : -1;
        } catch (NumberFormatException ex) {
            return -1;
        }
    }
}
