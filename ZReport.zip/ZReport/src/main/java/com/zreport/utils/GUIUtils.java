package com.zreport.utils;

import com.zreport.ZReport;
import com.zreport.managers.MessageManager;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

/** config.yml'deki "material / name / lore" bölümlerinden item üreten yardımcılar. */
public final class GUIUtils {

    /** Liste menülerinde rapor/oyuncu itemlerinin slotları (7x4 = 28). */
    public static final int[] LIST_SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34,
            37, 38, 39, 40, 41, 42, 43};

    private static final String[] WRAP_KEYS = {"reason", "review_note", "punishment_reason"};
    private static final int WRAP_WIDTH = 30;

    private GUIUtils() {
    }

    public static Material material(ZReport plugin, String path, Material fallback) {
        String name = plugin.getConfig().getString(path);
        Material material = name == null ? null : Material.matchMaterial(name);
        return material == null ? fallback : material;
    }

    public static ItemStack filler(ZReport plugin) {
        return ItemBuilder.of(material(plugin, "gui.filler.material", Material.GRAY_STAINED_GLASS_PANE))
                .name(plugin.getMessages().path("gui.filler.name")).build();
    }

    /** fullPath.material / .name / .lore okuyarak item üretir. */
    public static ItemStack item(ZReport plugin, String fullPath, Material fallback, String... ph) {
        MessageManager m = plugin.getMessages();
        return ItemBuilder.of(material(plugin, fullPath + ".material", fallback))
                .name(m.path(fullPath + ".name", ph))
                .lore(lore(m, plugin.getConfig().getStringList(fullPath + ".lore"), ph)).build();
    }

    public static ItemStack head(ZReport plugin, String fullPath, OfflinePlayer owner, String... ph) {
        MessageManager m = plugin.getMessages();
        return ItemBuilder.head(owner)
                .name(m.path(fullPath + ".name", ph))
                .lore(lore(m, plugin.getConfig().getStringList(fullPath + ".lore"), ph)).build();
    }

    /** Lore şablonlarını doldurur; uzun sebep/not metinlerini satırlara böler. */
    public static List<String> lore(MessageManager m, List<String> templates, String... ph) {
        List<String> out = new ArrayList<>();
        for (String template : templates) {
            String wrapKey = null;
            for (String key : WRAP_KEYS) {
                if (template.contains("%" + key + "%")) {
                    wrapKey = key;
                    break;
                }
            }
            String value = wrapKey == null ? null : valueOf(ph, wrapKey);
            if (value == null || value.length() <= WRAP_WIDTH) {
                out.add(m.apply(template, ph));
                continue;
            }
            List<String> chunks = TextUtil.wrap(value, WRAP_WIDTH);
            out.add(m.apply(template, withValue(ph, wrapKey, chunks.get(0))));
            for (int i = 1; i < chunks.size(); i++) {
                out.add("\u00A7f" + chunks.get(i));
            }
        }
        return out;
    }

    public static String[] merge(String[]... arrays) {
        int length = 0;
        for (String[] array : arrays) {
            length += array.length;
        }
        String[] result = new String[length];
        int index = 0;
        for (String[] array : arrays) {
            System.arraycopy(array, 0, result, index, array.length);
            index += array.length;
        }
        return result;
    }

    private static String valueOf(String[] ph, String key) {
        for (int i = 0; i + 1 < ph.length; i += 2) {
            if (ph[i].equals(key)) {
                return ph[i + 1];
            }
        }
        return null;
    }

    private static String[] withValue(String[] ph, String key, String value) {
        String[] copy = ph.clone();
        for (int i = 0; i + 1 < copy.length; i += 2) {
            if (copy[i].equals(key)) {
                copy[i + 1] = value;
            }
        }
        return copy;
    }
}
