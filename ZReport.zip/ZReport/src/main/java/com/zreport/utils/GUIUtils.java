package com.zreport.utils;

import com.zreport.ZReport;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * config.yml'deki "material / name / lore" bölümlerinden item üretir.
 * Şablonlar bir kez okunup renklendirilir ve önbelleğe alınır; her item yalnızca yer tutucu doldurur.
 */
public final class GUIUtils {

    /** Liste menülerinde rapor/oyuncu itemlerinin slotları (7x4 = 28). */
    public static final int[] LIST_SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34,
            37, 38, 39, 40, 41, 42, 43};

    private static final String[] WRAP_KEYS = {"reason", "review_note", "punishment_reason"};
    private static final int WRAP_WIDTH = 30;

    private record ItemTemplate(Material material, String name, List<String> lore) {
    }

    private static final Map<String, ItemTemplate> TEMPLATES = new ConcurrentHashMap<>();
    private static volatile ItemStack fillerItem;

    private GUIUtils() {
    }

    public static void clearCache() {
        TEMPLATES.clear();
        fillerItem = null;
    }

    public static Material material(ZReport plugin, String path, Material fallback) {
        String name = plugin.getConfig().getString(path);
        Material material = name == null ? null : Material.matchMaterial(name);
        return material == null ? fallback : material;
    }

    /** Dekoratif cam panel. Tek örnek paylaşılır; Bukkit slota yerleştirirken kopyalar. */
    public static ItemStack filler(ZReport plugin) {
        ItemStack filler = fillerItem;
        if (filler == null) {
            filler = ItemBuilder.of(material(plugin, "gui.filler.material", Material.GRAY_STAINED_GLASS_PANE))
                    .name(plugin.getMessages().path("gui.filler.name")).build();
            fillerItem = filler;
        }
        return filler;
    }

    private static ItemTemplate template(ZReport plugin, String fullPath, Material fallback) {
        ItemTemplate template = TEMPLATES.get(fullPath);
        if (template == null) {
            FileConfiguration config = plugin.getConfig();
            List<String> lore = new ArrayList<>();
            for (String line : config.getStringList(fullPath + ".lore")) {
                lore.add(TextUtil.colorize(line));
            }
            template = new ItemTemplate(
                    material(plugin, fullPath + ".material", fallback),
                    TextUtil.colorize(config.getString(fullPath + ".name", "&cEksik: " + fullPath)),
                    List.copyOf(lore));
            TEMPLATES.put(fullPath, template);
        }
        return template;
    }

    /** fullPath.material / .name / .lore okuyarak item üretir. */
    public static ItemStack item(ZReport plugin, String fullPath, Material fallback, String... ph) {
        ItemTemplate template = template(plugin, fullPath, fallback);
        return ItemBuilder.of(template.material())
                .name(TextUtil.fill(template.name(), ph))
                .lore(lore(template.lore(), ph)).build();
    }

    public static ItemStack head(ZReport plugin, String fullPath, OfflinePlayer owner, String... ph) {
        ItemTemplate template = template(plugin, fullPath, Material.PLAYER_HEAD);
        return ItemBuilder.head(owner)
                .name(TextUtil.fill(template.name(), ph))
                .lore(lore(template.lore(), ph)).build();
    }

    /** Lore şablonlarını doldurur; uzun sebep/not metinlerini satırlara böler. */
    private static List<String> lore(List<String> templates, String... ph) {
        List<String> out = new ArrayList<>(templates.size() + 2);
        for (String template : templates) {
            String wrapKey = null;
            for (String key : WRAP_KEYS) {
                if (template.contains("%" + key + "%")) {
                    wrapKey = key;
                    break;
                }
            }
            String value = wrapKey == null ? null : valueOf(ph, wrapKey);
            if (value == null || value.length() <= WRAP_WIDTH) {
                out.add(TextUtil.fill(template, ph));
                continue;
            }
            List<String> chunks = TextUtil.wrap(value, WRAP_WIDTH);
            out.add(TextUtil.fill(template, withValue(ph, wrapKey, chunks.get(0))));
            for (int i = 1; i < chunks.size(); i++) {
                out.add("\u00A7f" + chunks.get(i));
            }
        }
        return out;
    }

    public static String[] merge(String[]... arrays) {
        int length = 0;
        for (String[] array : arrays) {
            length += array.length;
        }
        String[] result = new String[length];
        int index = 0;
        for (String[] array : arrays) {
            System.arraycopy(array, 0, result, index, array.length);
            index += array.length;
        }
        return result;
    }

    private static String valueOf(String[] ph, String key) {
        for (int i = 0; i + 1 < ph.length; i += 2) {
            if (ph[i].equals(key)) {
                return ph[i + 1];
            }
        }
        return null;
    }

    private static String[] withValue(String[] ph, String key, String value) {
        String[] copy = ph.clone();
        for (int i = 0; i + 1 < copy.length; i += 2) {
            if (copy[i].equals(key)) {
                copy[i + 1] = value;
            }
        }
        return copy;
    }
}
