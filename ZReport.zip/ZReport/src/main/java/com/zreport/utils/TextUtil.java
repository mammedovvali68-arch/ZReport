package com.zreport.utils;

import org.bukkit.ChatColor;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public final class TextUtil {

    private static final Pattern WHITESPACE = Pattern.compile("\\s+");
    private static final Pattern CONTROL = Pattern.compile("\\p{Cntrl}");

    private TextUtil() {
    }

    public static String colorize(String text) {
        return text == null ? "" : ChatColor.translateAlternateColorCodes('&', text);
    }

    /**
     * %anahtar% yer tutucularını tek geçişte doldurur. Eklenen değerler tekrar taranmaz,
     * böylece kullanıcı girdisi başka yer tutucuları tetikleyemez.
     */
    public static String fill(String text, String... placeholders) {
        if (placeholders.length < 2 || text.indexOf('%') < 0) {
            return text;
        }
        StringBuilder out = new StringBuilder(text.length() + 16);
        int i = 0;
        int length = text.length();
        while (i < length) {
            char c = text.charAt(i);
            if (c == '%') {
                int end = text.indexOf('%', i + 1);
                if (end > i + 1) {
                    String value = lookup(placeholders, text, i + 1, end);
                    if (value != null) {
                        out.append(value);
                        i = end + 1;
                        continue;
                    }
                }
            }
            out.append(c);
            i++;
        }
        return out.toString();
    }

    private static String lookup(String[] placeholders, String text, int from, int to) {
        int keyLength = to - from;
        for (int i = 0; i + 1 < placeholders.length; i += 2) {
            String key = placeholders[i];
            if (key.length() == keyLength && text.startsWith(key, from)) {
                return placeholders[i + 1] == null ? "" : placeholders[i + 1];
            }
        }
        return null;
    }

    /** Kullanıcı girdisinden renk karakteri, kontrol karakterleri ve fazla boşlukları temizler. */
    public static String sanitize(String text) {
        if (text == null) {
            return "";
        }
        String cleaned = text.replace('\u00A7', ' ');
        cleaned = CONTROL.matcher(cleaned).replaceAll(" ");
        return WHITESPACE.matcher(cleaned).replaceAll(" ").trim();
    }

    public static boolean hasLetterOrDigit(String text) {
        for (int i = 0; i < text.length(); i++) {
            if (Character.isLetterOrDigit(text.charAt(i))) {
                return true;
            }
        }
        return false;
    }

    /** Metni verilen genişlikte satırlara böler (lore için). */
    public static List<String> wrap(String text, int width) {
        List<String> lines = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        for (String word : text.split(" ")) {
            while (word.length() > width) {
                if (current.length() > 0) {
                    lines.add(current.toString());
                    current.setLength(0);
                }
                lines.add(word.substring(0, width));
                word = word.substring(width);
            }
            if (current.length() + word.length() + (current.length() > 0 ? 1 : 0) > width) {
                lines.add(current.toString());
                current.setLength(0);
            }
            if (current.length() > 0) {
                current.append(' ');
            }
            current.append(word);
        }
        if (current.length() > 0 || lines.isEmpty()) {
            lines.add(current.toString());
        }
        return lines;
    }
}
