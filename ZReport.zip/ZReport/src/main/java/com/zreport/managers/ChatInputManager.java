package com.zreport.managers;

import com.zreport.ZReport;
import com.zreport.utils.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Consumer;
import java.util.function.Function;

/** GUI'den sohbete geçen metin girişleri (sebep, not). Süre dolunca veya iptalde GUI'ye dönülür. */
public class ChatInputManager {

    private record Pending(int maxLength, Function<String, String> validator, Consumer<String> onInput,
                           Runnable onCancel, long token) {
    }

    private final ZReport plugin;
    private final Map<UUID, Pending> pending = new ConcurrentHashMap<>();
    private final AtomicLong tokens = new AtomicLong();

    public ChatInputManager(ZReport plugin) {
        this.plugin = plugin;
    }

    private String cancelWord() {
        return plugin.getConfig().getString("settings.chat-input.cancel-word", "iptal");
    }

    private String skipWord() {
        return plugin.getConfig().getString("settings.chat-input.skip-word", "gec");
    }

    private int timeoutSeconds() {
        return Math.max(10, plugin.getConfig().getInt("settings.chat-input.timeout", 60));
    }

    /**
     * Oyuncunun bir sonraki sohbet mesajını yakalar.
     * validator: hata varsa biçimlendirilmiş mesaj, yoksa null. onInput boş metinle çağrılırsa giriş atlanmıştır.
     */
    public void request(Player player, String promptKey, int maxLength, Function<String, String> validator,
                        Consumer<String> onInput, Runnable onCancel) {
        UUID id = player.getUniqueId();
        long token = tokens.incrementAndGet();
        pending.put(id, new Pending(maxLength, validator, onInput, onCancel, token));
        int timeout = timeoutSeconds();
        plugin.getMessages().send(player, promptKey, "cancel", cancelWord(), "skip", skipWord(),
                "time", String.valueOf(timeout), "max", String.valueOf(maxLength));
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            Pending current = pending.get(id);
            if (current != null && current.token() == token) {
                pending.remove(id);
                if (player.isOnline()) {
                    plugin.getMessages().send(player, "input-timeout");
                    current.onCancel().run();
                }
            }
        }, timeout * 20L);
    }

    public boolean isWaiting(UUID id) {
        return pending.containsKey(id);
    }

    public void clear(UUID id) {
        pending.remove(id);
    }

    /** Ana thread'de çağrılır. */
    public void handle(Player player, String rawMessage) {
        UUID id = player.getUniqueId();
        Pending current = pending.get(id);
        if (current == null) {
            return;
        }
        String text = TextUtil.sanitize(rawMessage);
        if (text.equalsIgnoreCase(cancelWord())) {
            pending.remove(id);
            plugin.getMessages().send(player, "input-cancelled");
            current.onCancel().run();
            return;
        }
        if (text.isEmpty() || text.equalsIgnoreCase(skipWord())) {
            pending.remove(id);
            current.onInput().accept("");
            return;
        }
        if (text.length() > current.maxLength()) {
            plugin.getMessages().send(player, "input-too-long", "max", String.valueOf(current.maxLength()));
            return;
        }
        if (current.validator() != null) {
            String error = current.validator().apply(text);
            if (error != null) {
                player.sendMessage(error);
                return;
            }
        }
        pending.remove(id);
        current.onInput().accept(text);
    }
}
