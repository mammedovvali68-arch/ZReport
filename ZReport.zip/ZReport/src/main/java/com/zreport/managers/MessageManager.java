package com.zreport.managers;

import com.zreport.ZReport;
import com.zreport.models.Report;
import com.zreport.models.ReportStatus;
import com.zreport.utils.DateUtils;
import com.zreport.utils.TextUtil;
import org.bukkit.command.CommandSender;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** config.yml içindeki metinleri okur, renklendirir ve yer tutucuları doldurur. */
public class MessageManager {

    private final ZReport plugin;

    public MessageManager(ZReport plugin) {
        this.plugin = plugin;
    }

    /** Şablonu renklendirir, sonra yer tutucuları doldurur (kullanıcı girdisi renk kodu enjekte edemez). */
    public String apply(String template, String... placeholders) {
        String result = TextUtil.colorize(template);
        for (int i = 0; i + 1 < placeholders.length; i += 2) {
            result = result.replace("%" + placeholders[i] + "%", placeholders[i + 1] == null ? "" : placeholders[i + 1]);
        }
        return result;
    }

    /** Config'deki herhangi bir yolu metin olarak okur. */
    public String path(String fullPath, String... placeholders) {
        return apply(plugin.getConfig().getString(fullPath, "&cEksik: " + fullPath), placeholders);
    }

    public String raw(String key, String... placeholders) {
        return path("messages." + key, placeholders);
    }

    public String gui(String key, String... placeholders) {
        return path("gui." + key, placeholders);
    }

    public List<String> rawList(String key, String... placeholders) {
        List<String> out = new ArrayList<>();
        for (String line : plugin.getConfig().getStringList("messages." + key)) {
            out.add(apply(line, placeholders));
        }
        return out;
    }

    public String prefixed(String key, String... placeholders) {
        return TextUtil.colorize(plugin.getConfig().getString("messages.prefix", "")) + raw(key, placeholders);
    }

    public void send(CommandSender sender, String key, String... placeholders) {
        if (!raw(key, placeholders).isEmpty()) {
            sender.sendMessage(prefixed(key, placeholders));
        }
    }

    public String statusName(ReportStatus status) {
        return gui("status." + status.name().toLowerCase(Locale.ROOT) + ".name");
    }

    public String statusColor(ReportStatus status) {
        return gui("status." + status.name().toLowerCase(Locale.ROOT) + ".color");
    }

    public String typeLabel(String type) {
        if (type == null || type.isEmpty()) {
            return "-";
        }
        return apply(plugin.getConfig().getString("punishment.types." + type + ".label", type));
    }

    public String[] placeholders(Report report) {
        return placeholders(report, -1);
    }

    /** Rapor bilgilerini yer tutucu çiftlerine çevirir. total: hedefin toplam rapor sayısı (-1: bilinmiyor). */
    public String[] placeholders(Report report, int total) {
        String unknown = raw("unknown");
        String dash = "-";
        String reason = report.reason();
        String shortReason = reason.length() > 28 ? reason.substring(0, 27) + "\u2026" : reason;
        return new String[]{
                "id", String.valueOf(report.id()),
                "reported", report.reportedName(),
                "reported_uuid", report.reportedUuid() == null ? unknown : report.reportedUuid(),
                "reporter", report.reporterName(),
                "reporter_uuid", report.reporterUuid() == null ? unknown : report.reporterUuid(),
                "reason", reason,
                "reason_short", shortReason,
                "date", DateUtils.date(report.timestamp()),
                "time", DateUtils.time(report.timestamp()),
                "datetime", DateUtils.dateTime(report.timestamp()),
                "evidence", gui(report.evidence() ? "evidence-yes" : "evidence-no"),
                "status", statusName(report.status()),
                "status_color", statusColor(report.status()),
                "total", total < 0 ? dash : String.valueOf(total),
                "reviewed_by", report.reviewedByName() == null ? dash : report.reviewedByName(),
                "review_date", DateUtils.dateTime(report.reviewedAt()),
                "review_note", report.reviewNote() == null || report.reviewNote().isEmpty() ? dash : report.reviewNote(),
                "punishment_type", typeLabel(report.punishmentType()),
                "punishment_reason", report.punishmentReason() == null ? dash : report.punishmentReason(),
                "punishment_duration", DateUtils.human(report.punishmentDuration()),
                "punished_by", report.punishedByName() == null ? dash : report.punishedByName(),
                "punish_date", DateUtils.dateTime(report.punishedAt())
        };
    }
}
