package com.zreport.managers;

import com.zreport.ZReport;
import com.zreport.models.Report;
import com.zreport.utils.TextUtil;
import org.bukkit.command.CommandSender;

import java.util.ArrayList;
import java.util.List;

/** config.yml içindeki mesajları okur, renklendirir ve yer tutucuları doldurur. */
public class MessageManager {

    private final ZReport plugin;

    public MessageManager(ZReport plugin) {
        this.plugin = plugin;
    }

    /** Şablonu renklendirir, sonra yer tutucuları doldurur (kullanıcı girdisi renk kodu enjekte edemez). */
    public String apply(String template, String... placeholders) {
        String result = TextUtil.colorize(template);
        for (int i = 0; i + 1 < placeholders.length; i += 2) {
            result = result.replace("%" + placeholders[i] + "%", placeholders[i + 1] == null ? "" : placeholders[i + 1]);
        }
        return result;
    }

    public String raw(String key, String... placeholders) {
        return apply(plugin.getConfig().getString("messages." + key, "&cEksik mesaj: " + key), placeholders);
    }

    public List<String> rawList(String key, String... placeholders) {
        List<String> out = new ArrayList<>();
        for (String line : plugin.getConfig().getStringList("messages." + key)) {
            out.add(apply(line, placeholders));
        }
        return out;
    }

    public String prefixed(String key, String... placeholders) {
        return TextUtil.colorize(plugin.getConfig().getString("messages.prefix", "")) + raw(key, placeholders);
    }

    public void send(CommandSender sender, String key, String... placeholders) {
        String message = prefixed(key, placeholders);
        if (!raw(key, placeholders).isEmpty()) {
            sender.sendMessage(message);
        }
    }

    /** Rapor bilgilerini yer tutucu çiftlerine çevirir. */
    public String[] placeholders(Report report) {
        String unknown = raw("unknown");
        return new String[]{
                "id", String.valueOf(report.id()),
                "reported", report.reportedName(),
                "reported_uuid", report.reportedUuid() == null ? unknown : report.reportedUuid(),
                "reporter", report.reporterName(),
                "reporter_uuid", report.reporterUuid() == null ? unknown : report.reporterUuid(),
                "reason", report.reason(),
                "date", report.date(),
                "time", report.time()
        };
    }
}
