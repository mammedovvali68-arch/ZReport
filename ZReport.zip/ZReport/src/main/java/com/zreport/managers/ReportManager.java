package com.zreport.managers;

import com.zreport.ZReport;
import com.zreport.database.DatabaseManager;
import com.zreport.models.Report;
import com.zreport.models.ReportPage;
import org.bukkit.Bukkit;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import java.util.logging.Level;

/**
 * Raporlar üzerindeki işlemler. Veritabanı işleri asenkron çalışır,
 * sonuç callback'leri ana thread'de çağrılır (Bukkit API güvenliği).
 */
public class ReportManager {

    private final ZReport plugin;
    private final DatabaseManager database;

    public ReportManager(ZReport plugin, DatabaseManager database) {
        this.plugin = plugin;
        this.database = database;
    }

    public void createReport(Report draft, Consumer<Report> ok, Consumer<Throwable> err) {
        dispatch(database.supply(storage -> storage.insert(draft)), ok, err);
    }

    public void getPage(int page, int perPage, Consumer<ReportPage> ok, Consumer<Throwable> err) {
        boolean newestFirst = plugin.getConfig().getBoolean("settings.newest-first", false);
        int size = Math.max(1, perPage);
        dispatch(database.supply(storage -> {
            int total = storage.count();
            int pages = Math.max(1, (int) Math.ceil(total / (double) size));
            int current = Math.min(Math.max(1, page), pages);
            List<Report> list = total == 0 ? List.of() : storage.getPage((current - 1) * size, size, newestFirst);
            return new ReportPage(list, current, pages, total);
        }), ok, err);
    }

    public void getReport(int id, Consumer<Optional<Report>> ok, Consumer<Throwable> err) {
        dispatch(database.supply(storage -> storage.getById(id)), ok, err);
    }

    public void deleteReport(int id, Consumer<Boolean> ok, Consumer<Throwable> err) {
        dispatch(database.supply(storage -> storage.delete(id)), ok, err);
    }

    public void clearReports(Consumer<Integer> ok, Consumer<Throwable> err) {
        dispatch(database.supply(storage -> storage.clear()), ok, err);
    }

    private <T> void dispatch(CompletableFuture<T> future, Consumer<T> ok, Consumer<Throwable> err) {
        future.whenComplete((result, throwable) -> {
            if (!plugin.isEnabled()) {
                return;
            }
            try {
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (throwable != null) {
                        plugin.getLogger().log(Level.SEVERE, "Veritabanı işlemi başarısız oldu.", throwable);
                        if (err != null) {
                            err.accept(throwable);
                        }
                    } else {
                        ok.accept(result);
                    }
                });
            } catch (IllegalStateException ex) {
                // Eklenti tam bu sırada kapandı; yapılacak bir şey yok.
            }
        });
    }
}
