package com.zreport.managers;

import com.zreport.ZReport;
import com.zreport.database.DatabaseManager;
import com.zreport.database.ReportCache;
import com.zreport.models.PunishmentType;
import com.zreport.models.Report;
import com.zreport.models.ReportPage;
import com.zreport.models.ReportStatus;
import com.zreport.utils.Log;
import com.zreport.utils.Permissions;
import com.zreport.utils.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

/**
 * Raporlar üzerindeki işlemler. Veritabanı işleri asenkron çalışır, sonuç callback'leri ana thread'de
 * çağrılır. Her yazma işlemi, aynı veritabanı görevinin içinde önbelleği geçersiz kılar.
 */
public class ReportManager {

    private final ZReport plugin;
    private final DatabaseManager database;
    private final ReportCache cache;

    public ReportManager(ZReport plugin, DatabaseManager database) {
        this.plugin = plugin;
        this.database = database;
        this.cache = database.cache();
    }

    public ReportCache cache() {
        return cache;
    }

    /** Görevi veritabanı thread'inde çalıştırır, sonucu ana thread'de teslim eder. */
    public <T> void async(DatabaseManager.Task<T> task, Consumer<T> ok, Consumer<Throwable> err) {
        dispatch(database.supply(task), ok, err);
    }

    // ------------------------------------------------------------ oluşturma

    /** Boş Optional: aynı hedefe karşı zaten aktif raporun var. */
    public void createReport(Report draft, boolean checkDuplicate, Consumer<Optional<Report>> ok,
                             Consumer<Throwable> err) {
        async(storage -> {
            if (checkDuplicate && storage.existsActive(draft.reporterUuid(), draft.reportedUuid(), draft.reportedName())) {
                return Optional.<Report>empty();
            }
            Report saved = storage.insert(draft);
            cache.invalidate();
            Log.debug("Report #" + saved.id() + " created.");
            return Optional.of(saved);
        }, ok, err);
    }

    // ---------------------------------------------------------------- okuma

    public void getPage(int page, int perPage, Consumer<ReportPage> ok, Consumer<Throwable> err) {
        getPage(null, page, perPage, ok, err);
    }

    public void getPage(ReportStatus status, int page, int perPage, Consumer<ReportPage> ok,
                        Consumer<Throwable> err) {
        boolean newestFirst = plugin.getConfig().getBoolean("settings.newest-first", false);
        int size = Math.max(1, perPage);
        async(storage -> {
            int[] counts = cache.statusCounts(storage);
            int total = status == null ? counts[0] + counts[1] + counts[2] : counts[status.ordinal()];
            int pages = Math.max(1, (int) Math.ceil(total / (double) size));
            int current = Math.min(Math.max(1, page), pages);
            List<Report> list = total == 0 ? List.of() : storage.getPage(status, (current - 1) * size, size, newestFirst);
            Map<Integer, Integer> totals = list.isEmpty() ? Map.of() : storage.targetTotals(list);
            return new ReportPage(list, current, pages, total, totals, counts);
        }, ok, err);
    }

    public void getReport(int id, Consumer<Optional<Report>> ok, Consumer<Throwable> err) {
        if (id <= 0) {
            ok.accept(Optional.empty());
            return;
        }
        async(storage -> storage.getById(id), ok, err);
    }

    public void getStatusCounts(Consumer<int[]> ok, Consumer<Throwable> err) {
        async(storage -> cache.statusCounts(storage), ok, err);
    }

    // --------------------------------------------------------- durum değişimi

    public void markReviewed(int id, Player staff, String note, Consumer<Boolean> ok, Consumer<Throwable> err) {
        String uuid = staff.getUniqueId().toString();
        String name = staff.getName();
        String cleanNote = note == null || note.isEmpty() ? null : note;
        long at = System.currentTimeMillis();
        async(storage -> {
            boolean changed = storage.markReviewed(id, uuid, name, cleanNote, at);
            cache.invalidate();
            if (changed) {
                Log.debug("Report #" + id + " status updated to REVIEWED by " + name + ".");
            }
            return changed;
        }, ok, err);
    }

    public void markPunished(int id, PunishmentType type, String reason, long duration, Player staff,
                             Consumer<Boolean> ok, Consumer<Throwable> err) {
        String uuid = staff.getUniqueId().toString();
        String name = staff.getName();
        long at = System.currentTimeMillis();
        async(storage -> {
            boolean changed = storage.markPunished(id, type.name(), reason, duration, uuid, name, at);
            cache.invalidate();
            if (changed) {
                Log.debug("Report #" + id + " status updated to PUNISHED (" + type + ") by " + name + ".");
            }
            return changed;
        }, ok, err);
    }

    public void deleteReport(int id, Consumer<Boolean> ok, Consumer<Throwable> err) {
        async(storage -> {
            boolean deleted = storage.delete(id);
            cache.invalidate();
            return deleted;
        }, ok, err);
    }

    public void clearReports(Consumer<Integer> ok, Consumer<Throwable> err) {
        async(storage -> {
            int removed = storage.clear();
            cache.invalidate();
            Log.info("All reports cleared (" + removed + " removed).");
            return removed;
        }, ok, err);
    }

    // ------------------------------------------------------------- doğrulama

    public String defaultReason() {
        return plugin.getConfig().getString("messages.default-reason", "Sebep belirtilmedi");
    }

    /** Temizlenmiş (boş olmayan) sebep geçersizse biçimlendirilmiş hata mesajı, geçerliyse null. */
    public String reasonError(String reason) {
        int min = Math.max(1, plugin.getConfig().getInt("settings.min-reason-length", 3));
        int max = Math.max(min, plugin.getConfig().getInt("settings.max-reason-length", 150));
        MessageManager messages = plugin.getMessages();
        if (reason.length() < min || !TextUtil.hasLetterOrDigit(reason)) {
            return messages.prefixed("invalid-reason", "min", String.valueOf(min));
        }
        if (reason.length() > max) {
            return messages.prefixed("reason-too-long", "max", String.valueOf(max));
        }
        return null;
    }

    public int maxReasonLength() {
        return Math.max(1, plugin.getConfig().getInt("settings.max-reason-length", 150));
    }

    // -------------------------------------------------------------- bildirim

    public void notifyStaff(Report report, Player reporter) {
        if (!plugin.getConfig().getBoolean("settings.notify-staff", true)) {
            return;
        }
        MessageManager messages = plugin.getMessages();
        String[] placeholders = messages.placeholders(report);
        for (Player staff : Bukkit.getOnlinePlayers()) {
            if (!staff.equals(reporter) && staff.hasPermission(Permissions.LIST)) {
                messages.send(staff, "staff-notification", placeholders);
            }
        }
    }

    private <T> void dispatch(CompletableFuture<T> future, Consumer<T> ok, Consumer<Throwable> err) {
        future.whenComplete((result, throwable) -> {
            if (!plugin.isEnabled()) {
                return;
            }
            try {
                Bukkit.getScheduler().runTask(plugin, () -> deliver(result, throwable, ok, err));
            } catch (IllegalStateException ex) {
                // Eklenti tam bu sırada kapandı; yapılacak bir şey yok.
            }
        });
    }

    /** Ana thread'de çalışır; callback hataları sunucuyu veya diğer işlemleri etkilemez. */
    private <T> void deliver(T result, Throwable throwable, Consumer<T> ok, Consumer<Throwable> err) {
        try {
            if (throwable != null) {
                Log.error("Database operation failed", throwable);
                if (err != null) {
                    err.accept(throwable);
                }
            } else {
                ok.accept(result);
            }
        } catch (RuntimeException ex) {
            Log.error("Error while handling a database result", ex);
        }
    }
}
