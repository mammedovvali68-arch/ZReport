package com.zreport.managers;

import com.zreport.ZReport;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class CooldownManager {

    private final ZReport plugin;
    private final Map<UUID, Long> expiries = new ConcurrentHashMap<>();

    public CooldownManager(ZReport plugin) {
        this.plugin = plugin;
    }

    /** Kalan bekleme süresi (saniye, yukarı yuvarlanır). 0 ise beklemeye gerek yok. */
    public long remainingSeconds(UUID id) {
        Long expiry = expiries.get(id);
        if (expiry == null) {
            return 0;
        }
        long remaining = expiry - System.currentTimeMillis();
        if (remaining <= 0) {
            expiries.remove(id);
            return 0;
        }
        return (remaining + 999) / 1000;
    }

    public void mark(UUID id) {
        int seconds = Math.max(0, plugin.getConfig().getInt("settings.cooldown", 30));
        long now = System.currentTimeMillis();
        if (expiries.size() > 256) {
            expiries.values().removeIf(expiry -> expiry <= now);
        }
        expiries.put(id, now + seconds * 1000L);
    }

    public void clear(UUID id) {
        expiries.remove(id);
    }
}
