package com.zreport.managers;

import com.zreport.ZReport;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Silme/temizleme işlemleri için süreli onay mekanizması. */
public class ConfirmationManager {

    private record Pending(String action, long expiresAt) {
    }

    private final ZReport plugin;
    private final Map<String, Pending> pending = new ConcurrentHashMap<>();

    public ConfirmationManager(ZReport plugin) {
        this.plugin = plugin;
    }

    public int timeoutSeconds() {
        return Math.max(5, plugin.getConfig().getInt("settings.confirmation-timeout", 15));
    }

    public void request(CommandSender sender, String action) {
        long now = System.currentTimeMillis();
        if (pending.size() > 100) {
            pending.values().removeIf(p -> p.expiresAt() < now);
        }
        pending.put(key(sender), new Pending(action, now + timeoutSeconds() * 1000L));
    }

    /** Bekleyen onay bu işlem için geçerliyse tüketir ve true döner. */
    public boolean consume(CommandSender sender, String action) {
        String key = key(sender);
        Pending p = pending.get(key);
        if (p == null) {
            return false;
        }
        if (p.expiresAt() < System.currentTimeMillis()) {
            pending.remove(key, p);
            return false;
        }
        if (!p.action().equals(action)) {
            return false;
        }
        pending.remove(key, p);
        return true;
    }

    public void clear(CommandSender sender) {
        pending.remove(key(sender));
    }

    private String key(CommandSender sender) {
        return sender instanceof Player player ? player.getUniqueId().toString() : "CONSOLE";
    }
}
