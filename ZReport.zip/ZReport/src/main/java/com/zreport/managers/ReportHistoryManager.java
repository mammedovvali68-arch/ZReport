package com.zreport.managers;

import com.zreport.ZReport;
import com.zreport.models.Report;
import com.zreport.models.ReportPage;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;

/** Oyuncu bazlı rapor geçmişi. Kayıtlar Report ID üzerinden bağımsız tutulur; UUID esas alınır. */
public class ReportHistoryManager {

    public record PlayerHistory(int total, int active, int reviewed, int punished, List<Report> recent) {
    }

    public record ReportDetails(Report report, PlayerHistory history) {
    }

    public record HistoryPage(ReportPage page, PlayerHistory summary) {
    }

    private final ZReport plugin;

    public ReportHistoryManager(ZReport plugin) {
        this.plugin = plugin;
    }

    /** Raporu ve hedef oyuncunun önceki raporlarını tek seferde yükler. */
    public void loadDetails(int id, Consumer<Optional<ReportDetails>> ok, Consumer<Throwable> err) {
        int preview = Math.max(1, plugin.getConfig().getInt("settings.details-history-preview", 5));
        plugin.getReportManager().async(storage -> {
            Optional<Report> found = storage.getById(id);
            if (found.isEmpty()) {
                return Optional.<ReportDetails>empty();
            }
            Report report = found.get();
            int[] counts = plugin.getReportManager().cache().targetCounts(storage, report.reportedUuid(), report.reportedName());
            List<Report> recent = new ArrayList<>();
            for (Report other : storage.targetPage(report.reportedUuid(), report.reportedName(), 0, preview + 1)) {
                if (other.id() != report.id() && recent.size() < preview) {
                    recent.add(other);
                }
            }
            return Optional.of(new ReportDetails(report,
                    new PlayerHistory(counts[0], counts[1], counts[2], counts[3], recent)));
        }, ok, err);
    }

    /** Bir oyuncunun rapor geçmişi sayfası + özet sayıları. */
    public void loadHistoryPage(String uuid, String name, int page, int perPage, Consumer<HistoryPage> ok,
                                Consumer<Throwable> err) {
        int size = Math.max(1, perPage);
        plugin.getReportManager().async(storage -> {
            int[] counts = plugin.getReportManager().cache().targetCounts(storage, uuid, name);
            int pages = Math.max(1, (int) Math.ceil(counts[0] / (double) size));
            int current = Math.min(Math.max(1, page), pages);
            List<Report> list = counts[0] == 0 ? List.of() : storage.targetPage(uuid, name, (current - 1) * size, size);
            ReportPage reportPage = new ReportPage(list, current, pages, counts[0], Map.of(), new int[3]);
            return new HistoryPage(reportPage, new PlayerHistory(counts[0], counts[1], counts[2], counts[3], list));
        }, ok, err);
    }
}
